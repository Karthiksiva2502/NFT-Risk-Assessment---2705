# Functions for Chroma DB interactions and embedding generation
import chromadb
from chromadb.utils import embedding_functions
import openai
import uuid
import os
import time
import requests
import backoff  # Add this import
import logging  # Add this import
import json
from datetime import datetime

# Configure enhanced logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("chroma_operations.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("chroma_logic")

# --- Configuration ---
CHROMA_DB_PATH = "./chroma_db"
COLLECTION_NAME = "requirements_assessments"
EMBEDDING_MODEL = "text-embedding-3-small"  # Updated to the newer model
DEFAULT_SIMILARITY_THRESHOLD = 0.7 # Default distance threshold (lower means more similar, higher means less strict)
DEFAULT_N_RESULTS = 5 # Default number of results to fetch
MAX_RETRIES = 3  # Maximum number of retries for API calls

# --- ChromaDB Client Initialization ---
# Ensure the directory exists
os.makedirs(CHROMA_DB_PATH, exist_ok=True)
logger.info(f"Ensuring ChromaDB directory exists at: {CHROMA_DB_PATH}")

# Use PersistentClient for saving data to disk
try:
    client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
    logger.info(f"ChromaDB PersistentClient initialized successfully at {CHROMA_DB_PATH}")
except Exception as e:
    logger.error(f"Failed to initialize ChromaDB client: {str(e)}")
    raise

# --- Connectivity Check ---
def check_openai_connectivity(api_key):
    """
    Check if we can connect to OpenAI API.
    Raises openai.AuthenticationError or ConnectionError on failure.
    Returns True on success.
    """
    try:
        client = openai.OpenAI(api_key=api_key)
        client.models.list() # A lightweight call to check connectivity and auth
        logger.info("OpenAI API connectivity and authentication successful.")
        return True
    except openai.APIConnectionError as e:
        logger.error(f"Cannot connect to OpenAI API - network connectivity issue: {e}")
        raise ConnectionError(f"Failed to connect to OpenAI. Please check your network connection and firewall settings: {str(e)}")
    except openai.AuthenticationError as e:
        logger.error(f"OpenAI API authentication failed - check API key: {e}")
        raise # Re-raise the original AuthenticationError to be caught specifically
    except Exception as e: # Catch any other OpenAI or general exceptions during the check
        logger.error(f"OpenAI API check failed with an unexpected error: {e}")
        # Wrap in a more generic exception if it's not already an OpenAI one
        raise Exception(f"An unexpected error occurred during OpenAI API check: {str(e)}")

# --- Embedding Function ---
# Note: API key is passed dynamically now
def get_openai_embedding_function(api_key):
    """Returns a ChromaDB embedding function configured with the provided API key."""
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    # This uses Chroma's helper, which internally handles the OpenAI client setup
    return embedding_functions.OpenAIEmbeddingFunction(
        api_key=api_key,
        model_name=EMBEDDING_MODEL
    )

# --- Collection Handling ---
def get_or_create_collection(api_key):
    """
    Gets or creates the ChromaDB collection with the appropriate embedding function.
    Propagates exceptions from check_openai_connectivity.
    """
    logger.info(f"Attempting to get or create collection: {COLLECTION_NAME}")
    start_time = time.time()
    
    try:
        check_openai_connectivity(api_key) # Will raise AuthenticationError or ConnectionError on failure
            
        openai_ef = get_openai_embedding_function(api_key)
        collection = client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=openai_ef,
            metadata={"hnsw:space": "cosine"} # Use cosine distance for similarity
        )
        
        elapsed = time.time() - start_time
        collection_count = collection.count()
        logger.info(f"Successfully got/created collection '{COLLECTION_NAME}' with {collection_count} documents in {elapsed:.2f}s")
        return collection
    except Exception as e:
        logger.error(f"Failed to get/create collection: {str(e)}")
        raise

# Define exponential backoff for API calls
@backoff.on_exception(
    backoff.expo,
    (openai.RateLimitError, openai.APIConnectionError, requests.exceptions.RequestException),
    max_tries=MAX_RETRIES
)
def _generate_embedding_with_retry(text, api_key):
    """Internal function to generate embedding with retry logic."""
    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=[text]  # API expects a list
    )
    return response.data[0].embedding

# --- Core Functions ---
def generate_embedding(text, api_key):
    """
    Generates embedding for a given text using OpenAI with retry logic.
    Propagates exceptions from check_openai_connectivity or embedding generation.
    """
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    
    check_openai_connectivity(api_key) # Initial check, raises on failure

    try:
        return _generate_embedding_with_retry(text, api_key)
    except openai.AuthenticationError: # If auth fails specifically during embedding call
        logger.error("Authentication error during embedding generation attempt.")
        raise # Re-raise to be caught by app.py
    except openai.APIConnectionError as e: # Should be caught by backoff, but as a fallback
        logger.error(f"Connection error during embedding generation (post-retry or unhandled by backoff): {e}")
        raise ConnectionError(f"Failed to connect to OpenAI for embedding after retries: {str(e)}")
    except openai.RateLimitError as e:
        logger.error(f"Rate limit exceeded during embedding generation: {e}")
        raise Exception(f"OpenAI rate limit exceeded during embedding: {str(e)}. Please try again later.")
    except Exception as e: # Catch-all for other unexpected errors
        logger.error(f"Unexpected error generating embedding: {e}")
        raise Exception(f"An unexpected error occurred while generating embedding: {str(e)}")

# Update function signature to accept project_name
def add_assessment(collection, requirement_text, embedding, risk, reasoning, recommendations, impact, project_name):
    """Adds a new assessment to the ChromaDB collection."""
    doc_id = str(uuid.uuid4())
    timestamp = int(time.time())
    
    logger.info(f"Adding new assessment with ID: {doc_id}, Project: {project_name}, Risk: {risk}")
    
    metadata = {
        "requirement_text": requirement_text,
        "risk": risk,
        "reasoning": reasoning,
        "recommendations": recommendations,
        "impact": impact,
        "project_name": project_name,
        "status": "Pending",
        "comments": "",
        "timestamp": timestamp,
        "id": doc_id
    }
    
    try:
        collection.add(
            documents=[requirement_text],
            embeddings=[embedding],
            metadatas=[metadata],
            ids=[doc_id]
        )
        logger.info(f"Assessment added successfully with ID: {doc_id}")
        
        # Log detailed info at debug level
        logger.debug(f"Assessment details - ID: {doc_id}, Text length: {len(requirement_text)}, "
                    f"Embedding dimensions: {len(embedding)}")
        
        return doc_id
    except Exception as e:
        logger.error(f"Error adding assessment to Chroma: {str(e)}")
        return None

def find_similar_requirements(collection, embedding, n_results=DEFAULT_N_RESULTS, custom_threshold=DEFAULT_SIMILARITY_THRESHOLD):
    """
    Finds similar requirements in the collection based on embedding.
    Args:
        collection: The ChromaDB collection object.
        embedding: The query embedding.
        n_results (int): The number of results to retrieve from ChromaDB.
        custom_threshold (float): The distance threshold for similarity (distance < threshold).
        
    Returns:
        List of dictionaries containing similar requirements with metadata, distance scores,
        and calculated similarity percentages.
    """
    if embedding is None:
        logger.warning("Null embedding provided to find_similar_requirements")
        return None
    
    logger.info(f"Searching for similar requirements with threshold: {custom_threshold}, max results: {n_results}")
    start_time = time.time()
    
    try:
        # Request more results than needed for better filtering
        retrieve_count = min(n_results * 3, 20)
        results = collection.query(
            query_embeddings=[embedding],
            n_results=retrieve_count,
            include=['metadatas', 'distances', 'documents']
        )

        # Process results
        similar_docs = []
        if results and results.get('ids') and results['ids'][0]:
            for i, doc_id in enumerate(results['ids'][0]):
                distance = results['distances'][0][i]
                if distance < custom_threshold:
                    metadata = results['metadatas'][0][i]
                    document = results['documents'][0][i] if 'documents' in results else ""
                    similarity_percentage = round((1 - distance) * 100, 2)
                    
                    similar_docs.append({
                        "id": doc_id,
                        "distance": distance,
                        "similarity_percentage": similarity_percentage,
                        "metadata": metadata,
                        "document": document[:250] + "..." if len(document) > 250 else document
                    })
            
            similar_docs.sort(key=lambda x: x['distance'])
            similar_docs = similar_docs[:n_results]
            
            for doc in similar_docs:
                if doc['similarity_percentage'] >= 90:
                    doc['match_quality'] = "Strong match"
                elif doc['similarity_percentage'] >= 75:
                    doc['match_quality'] = "Good match"
                elif doc['similarity_percentage'] >= 60:
                    doc['match_quality'] = "Moderate match"
                else:
                    doc['match_quality'] = "Weak match"
        
        elapsed = time.time() - start_time
        found_count = len(similar_docs)
        
        logger.info(f"Search completed in {elapsed:.2f}s. Found {found_count} similar documents out of {retrieve_count} retrieved")
        if found_count > 0:
            logger.debug(f"Top match similarity: {similar_docs[0]['similarity_percentage']}%, match quality: {similar_docs[0]['match_quality']}")
        
        return similar_docs
    except Exception as e:
        logger.error(f"Error querying Chroma for similar requirements: {str(e)}")
        return None

# Add a new function to provide statistics about the vector database
def get_collection_stats(collection):
    """
    Returns statistics about the collection for monitoring purposes.
    
    Args:
        collection: The ChromaDB collection object.
        
    Returns:
        Dictionary with statistics about the collection.
    """
    try:
        # Get all items count
        count = collection.count()
        
        # Get risk distribution if available
        results = collection.get(include=['metadatas'])
        
        stats = {
            "total_entries": count,
            "risk_distribution": {
                "High": 0,
                "Medium": 0, 
                "Low": 0,
                "Unknown": 0
            },
            "status_distribution": {
                "Approved": 0,
                "Rejected": 0,
                "Pending": 0,
                "Other": 0
            },
            "last_updated": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        }
        
        # Calculate distributions
        if results and results.get('metadatas'):
            for metadata in results['metadatas']:
                # Risk distribution
                risk = metadata.get('risk', 'Unknown')
                if risk in stats["risk_distribution"]:
                    stats["risk_distribution"][risk] += 1
                else:
                    stats["risk_distribution"]["Unknown"] += 1
                    
                # Status distribution
                status = metadata.get('status', 'Other')
                if status in stats["status_distribution"]:
                    stats["status_distribution"][status] += 1
                else:
                    stats["status_distribution"]["Other"] += 1
        
        return stats
    except Exception as e:
        logger.error(f"Error getting collection stats: {e}")
        return {"error": str(e), "total_entries": 0}

# Add function to perform semantic search with keywords
def semantic_search(collection, query_text, api_key, n_results=DEFAULT_N_RESULTS, custom_threshold=DEFAULT_SIMILARITY_THRESHOLD):
    """
    Performs semantic search using natural language query instead of embeddings.
    
    Args:
        collection: The ChromaDB collection object.
        query_text: The search query in natural language.
        api_key: OpenAI API key for embedding generation.
        n_results: Maximum number of results to return.
        custom_threshold: Similarity threshold.
        
    Returns:
        List of search results with similarity scores.
    """
    if not query_text or not api_key:
        return None
    
    try:
        # Generate embedding for the query text
        query_embedding = generate_embedding(query_text, api_key)
        
        # Use the existing find_similar_requirements function
        return find_similar_requirements(
            collection,
            query_embedding,
            n_results=n_results,
            custom_threshold=custom_threshold
        )
    except Exception as e:
        logger.error(f"Error in semantic search: {e}")
        return None

# Add functionality to export/backup vector database
def export_collection_data(collection, output_file="chroma_backup.json"):
    """
    Exports all data from the collection to a JSON file as backup.
    
    Args:
        collection: The ChromaDB collection object.
        output_file: Path to save the backup file.
        
    Returns:
        Boolean indicating success or failure.
    """
    try:
        # Get all data
        results = collection.get(include=['metadatas', 'documents', 'embeddings'])
        
        # Prepare export data
        export_data = {
            "ids": results.get('ids', []),
            "metadatas": results.get('metadatas', []),
            "documents": results.get('documents', []),
            "embeddings": results.get('embeddings', []),
            "export_timestamp": int(time.time()),
            "export_date": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        }
        
        # Save to file
        with open(output_file, 'w') as f:
            import json
            json.dump(export_data, f)
        
        logger.info(f"Successfully exported {len(export_data['ids'])} records to {output_file}")
        return True
    except Exception as e:
        logger.error(f"Error exporting collection data: {e}")
        return False

# Renamed function and updated to handle generic status
def update_assessment_status(collection, doc_id, new_status, comments):
    """Updates the status and comments for a specific assessment."""
    if new_status not in ["Approved", "Rejected", "Pending"]: # Basic validation
        logger.error(f"Invalid status '{new_status}' provided.")
        return False
    try:
        # Chroma doesn't have a direct 'update metadata' for a single field easily.
        # We get the existing record, update metadata, and use 'update' (or upsert).
        existing_record = collection.get(ids=[doc_id], include=['metadatas', 'embeddings', 'documents'])

        if not existing_record or not existing_record.get('ids'):
            logger.error(f"Document with ID {doc_id} not found for update.")
            return False

        # Assuming only one record is returned for the ID
        current_metadata = existing_record['metadatas'][0]
        current_embedding = existing_record['embeddings'][0]
        current_document = existing_record['documents'][0]

        # Update the metadata
        current_metadata['status'] = new_status # Use the new status field
        current_metadata['comments'] = comments if comments else "" # Ensure comments is not None
        if 'approved' in current_metadata: # Remove old 'approved' field if it exists
            del current_metadata['approved']


        # Use upsert to update the record
        collection.upsert(
            ids=[doc_id],
            embeddings=[current_embedding],
            documents=[current_document],
            metadatas=[current_metadata]
        )
        logger.info(f"Updated status to '{new_status}' for ID: {doc_id}")
        return True
    except Exception as e:
        logger.error(f"Error updating assessment status in Chroma: {str(e)}")
        return False

def get_all_assessments(collection):
    """Retrieves all assessments from the collection."""
    try:
        # Get all items. Be cautious with very large collections.
        # Consider pagination or filtering if performance becomes an issue.
        # 'ids' are returned by default and should not be in 'include'
        start_time = time.time()
        results = collection.get(include=['metadatas']) # Removed 'ids' from include
        assessments = []
        if results and results.get('ids'): # Check if 'ids' key exists in the result
            for i, doc_id in enumerate(results['ids']):
                 # Ensure metadatas list is long enough
                 if i < len(results.get('metadatas', [])):
                     metadata = results['metadatas'][i]
                 else:
                     metadata = {} # Handle case where metadata might be missing unexpectedly

                 # Add the ID to the metadata dict if it's not already there
                 if metadata is not None and 'id' not in metadata:
                     metadata['id'] = doc_id
                 assessments.append(metadata)
        # Sort by timestamp descending (newest first)
        assessments.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        
        # Log operation statistics
        log_operation_stats("fetch_all_assessments", start_time, True, {"count": len(assessments)})
        return assessments
    except Exception as e:
        logger.error(f"Error retrieving all assessments from Chroma: {str(e)}")
        log_operation_stats("fetch_all_assessments", start_time, False, {"error": str(e)})
        return []

# Add a function to log operation statistics
def log_operation_stats(operation_name, start_time, success=True, details=None):
    """Helper function to log operation statistics"""
    elapsed = time.time() - start_time
    status = "SUCCESS" if success else "FAILURE"
    
    log_data = {
        "operation": operation_name,
        "status": status,
        "duration_seconds": round(elapsed, 3),
        "timestamp": datetime.now().isoformat(),
    }
    
    if details:
        log_data.update(details)
    
    log_message = f"{operation_name} {status.lower()} - {elapsed:.2f}s"
    if details:
        log_message += f" - details: {json.dumps(details)}"
    
    if success:
        logger.info(log_message)
    else:
        logger.error(log_message)
    
    # Write structured log data to a separate file for potential analytics
    try:
        with open("operation_stats.log", "a") as f:
            f.write(json.dumps(log_data) + "\n")
    except Exception as e:
        logger.warning(f"Failed to write to operation_stats.log: {str(e)}")
