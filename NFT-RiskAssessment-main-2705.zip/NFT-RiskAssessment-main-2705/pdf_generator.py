# Function to generate PDF reports using FPDF2
from fpdf import FPDF
import time
import uuid

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Requirement Risk Assessment Report', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.set_font('Arial', '', 10)
        # Use multi_cell for automatic line breaks
        self.multi_cell(0, 5, body)
        self.ln()

    def add_assessment_section(self, title, content):
        self.set_font('Arial', 'B', 10)
        self.cell(0, 6, title, 0, 1, 'L')
        self.set_font('Arial', '', 10)
        # Replace non-breaking spaces or other problematic chars if needed
        content_cleaned = content.replace('\u2022', '-').encode('latin-1', 'replace').decode('latin-1')
        self.multi_cell(0, 5, content_cleaned)
        self.ln(3)


def generate_pdf_report(assessment_data):
    """
    Generates a PDF report from the assessment data.

    Args:
        assessment_data (dict): A dictionary containing all assessment details.
                                Expected keys: 'requirement_text', 'context', 'risk',
                                'reasoning', 'recommendations', 'impact',
                                'approved', 'comments', 'timestamp', 'id'.

    Returns:
        bytes: The generated PDF content as bytes.
    """
    pdf = PDF()
    pdf.add_page()

    # --- Requirement ---
    pdf.chapter_title("Requirement Details")
    pdf.add_assessment_section("Requirement Text:", assessment_data.get('requirement_text', 'N/A'))

    # --- Context ---
    pdf.chapter_title("Context Provided")
    context = assessment_data.get('context', {})
    context_str = (
        f"- Project Type: {context.get('project_type', 'N/A')}\n"
        f"- Handles Sensitive Data: {context.get('sensitive_data', 'N/A')}\n"
        f"- Expected User Volume: {context.get('user_volume', 'N/A')}\n"
        f"- Performance Expectations: {context.get('performance', 'N/A')}\n"
        f"- Accessibility Required: {context.get('accessibility', 'N/A')}\n"
        f"- Third-Party API Integrations: {context.get('integrations', 'N/A')}\n"
        f"- Required Uptime/Availability: {context.get('uptime', 'N/A')}"
    )
    pdf.chapter_body(context_str)

    # --- Assessment Results ---
    pdf.chapter_title("Risk Assessment Results")
    pdf.add_assessment_section("Assessed Risk Level:", assessment_data.get('risk', 'N/A'))
    pdf.add_assessment_section("Reasoning:", assessment_data.get('reasoning', 'N/A'))
    pdf.add_assessment_section("Recommended Testing:", assessment_data.get('recommendations', 'N/A'))
    pdf.add_assessment_section("Impact of Not Testing:", assessment_data.get('impact', 'N/A'))

    # --- Approval Status ---
    pdf.chapter_title("Architect Review Status")
    # Use the 'status' field, default to 'Pending' if not found
    status_text = assessment_data.get('status', 'Pending')
    pdf.add_assessment_section("Status:", status_text)
    pdf.add_assessment_section("Comments:", assessment_data.get('comments', 'None'))

    # --- Metadata ---
    pdf.ln(10)
    pdf.set_font('Arial', 'I', 8)
    report_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(assessment_data.get('timestamp', time.time())))
    pdf.cell(0, 5, f"Report Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}", 0, 1, 'L')
    pdf.cell(0, 5, f"Assessment Timestamp: {report_time}", 0, 1, 'L')
    pdf.cell(0, 5, f"Assessment ID: {assessment_data.get('id', 'N/A')}", 0, 1, 'L')


    # Return PDF content as bytes
    # 'S' destination returns bytearray, convert explicitly to bytes for Streamlit
    return bytes(pdf.output(dest='S'))

# Example Usage (for testing)
if __name__ == '__main__':
    dummy_data = {
        'requirement_text': "The system must allow users to upload profile pictures.",
        'context': {
            'project_type': 'Enhancement', 'sensitive_data': 'Yes (PII)',
            'user_volume': 'Medium (1000 concurrent)', 'performance': 'High (sub-second uploads)',
            'accessibility': 'Yes (WCAG AA)', 'integrations': 'No', 'uptime': '99.9%'
        },
        'risk': 'Medium',
        'reasoning': 'Handles PII (profile pictures) and has performance requirements. Needs security and load testing.',
        'recommendations': '- Security Testing: Scan for vulnerabilities related to image uploads.\n- Performance Testing: Verify upload times under load.\n- Accessibility Testing: Ensure upload controls are accessible.',
        'impact': 'Failure to test could lead to data exposure or poor user experience during uploads.',
        'approved': True,
        'comments': 'Approved after verifying security scan results.',
        'timestamp': int(time.time()) - 86400, # Yesterday
        'id': str(uuid.uuid4())
    }
    pdf_bytes = generate_pdf_report(dummy_data)
    with open("sample_report.pdf", "wb") as f:
        f.write(pdf_bytes)
    print("Sample PDF report generated: sample_report.pdf")
