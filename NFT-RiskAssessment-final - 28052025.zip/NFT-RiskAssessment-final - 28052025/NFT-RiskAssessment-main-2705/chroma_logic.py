# Functions for Chroma DB interactions and embedding generation
import chromadb
from chromadb.utils import embedding_functions
from chromadb import errors as chromadb_errors  # Import chromadb errors explicitly
import openai
import uuid
import os
import time
import requests
import backoff  # For retry logic
import logging  # For enhanced logging
import json
from datetime import datetime

# Configure enhanced logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("chroma_operations.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("chroma_logic")

# --- Configuration ---
CHROMA_DB_PATH = "./chroma_db"
COLLECTION_NAME = "requirements_assessments"
EMBEDDING_MODEL = "text-embedding-3-small"  # Updated to the newer model
DEFAULT_SIMILARITY_THRESHOLD = 0.7 # Default distance threshold (lower means more similar, higher means less strict)
DEFAULT_N_RESULTS = 5 # Default number of results to fetch
MAX_RETRIES = 3  # Maximum number of retries for API calls

# --- ChromaDB Client Initialization ---
# Ensure the directory exists
os.makedirs(CHROMA_DB_PATH, exist_ok=True)
logger.info(f"Ensuring ChromaDB directory exists at: {CHROMA_DB_PATH}")

# Use PersistentClient for saving data to disk
try:
    client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
    logger.info(f"ChromaDB PersistentClient initialized successfully at {CHROMA_DB_PATH}")
except Exception as e:
    logger.error(f"Failed to initialize ChromaDB client: {str(e)}")
    raise

# --- Connectivity Check ---
def check_openai_connectivity(api_key):
    """
    Check if we can connect to OpenAI API.
    Raises openai.AuthenticationError or ConnectionError on failure.
    Returns True on success.
    """
    try:
        client = openai.OpenAI(api_key=api_key)
        client.models.list() # A lightweight call to check connectivity and auth
        logger.info("OpenAI API connectivity and authentication successful.")
        return True
    except openai.APIConnectionError as e:
        logger.error(f"Cannot connect to OpenAI API - network connectivity issue: {e}")
        raise ConnectionError(f"Failed to connect to OpenAI. Please check your network connection and firewall settings: {str(e)}")
    except openai.AuthenticationError as e:
        logger.error(f"OpenAI API authentication failed - check API key: {e}")
        raise # Re-raise the original AuthenticationError to be caught specifically
    except Exception as e: # Catch any other OpenAI or general exceptions during the check
        logger.error(f"OpenAI API check failed with an unexpected error: {e}")
        # Wrap in a more generic exception if it's not already an OpenAI one
        raise Exception(f"An unexpected error occurred during OpenAI API check: {str(e)}")

# --- Embedding Function ---
# Note: API key is passed dynamically now
def get_openai_embedding_function(api_key):
    """Returns a ChromaDB embedding function configured with the provided API key."""
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    # This uses Chroma's helper, which internally handles the OpenAI client setup
    return embedding_functions.OpenAIEmbeddingFunction(
        api_key=api_key,
        model_name=EMBEDDING_MODEL
    )

# --- Collection Handling ---
def get_or_create_collection(api_key):
    """
    Gets or creates the ChromaDB collection with the appropriate embedding function.
    Propagates exceptions from check_openai_connectivity.
    """
    logger.info(f"Attempting to get or create collection: {COLLECTION_NAME}")
    start_time = time.time()
    
    try:
        check_openai_connectivity(api_key) # Will raise AuthenticationError or ConnectionError on failure
            
        openai_ef = get_openai_embedding_function(api_key)
        collection = client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=openai_ef,
            metadata={"hnsw:space": "cosine"} # Use cosine distance for similarity
        )
        
        elapsed = time.time() - start_time
        collection_count = collection.count()
        logger.info(f"Successfully got/created collection '{COLLECTION_NAME}' with {collection_count} documents in {elapsed:.2f}s")
        return collection
    except Exception as e:
        logger.error(f"Failed to get/create collection: {str(e)}")
        raise

# Define exponential backoff for API calls
@backoff.on_exception(
    backoff.expo,
    (openai.RateLimitError, openai.APIConnectionError, requests.exceptions.RequestException),
    max_tries=MAX_RETRIES
)
def _generate_embedding_with_retry(text, api_key):
    """Internal function to generate embedding with retry logic."""
    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=[text]  # API expects a list
    )
    return response.data[0].embedding

# --- Core Functions ---
def generate_embedding(text, api_key):
    """
    Generates embedding for a given text using OpenAI with retry logic.
    Propagates exceptions from check_openai_connectivity or embedding generation.
    """
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    
    check_openai_connectivity(api_key) # Initial check, raises on failure

    try:
        return _generate_embedding_with_retry(text, api_key)
    except openai.AuthenticationError: # If auth fails specifically during embedding call
        logger.error("Authentication error during embedding generation attempt.")
        raise # Re-raise to be caught by app.py
    except openai.APIConnectionError as e: # Should be caught by backoff, but as a fallback
        logger.error(f"Connection error during embedding generation (post-retry or unhandled by backoff): {e}")
        raise ConnectionError(f"Failed to connect to OpenAI for embedding after retries: {str(e)}")
    except openai.RateLimitError as e:
        logger.error(f"Rate limit exceeded during embedding generation: {e}")
        raise Exception(f"OpenAI rate limit exceeded during embedding: {str(e)}. Please try again later.")
    except Exception as e: # Catch-all for other unexpected errors
        logger.error(f"Unexpected error generating embedding: {e}")
        raise Exception(f"An unexpected error occurred while generating embedding: {str(e)}")

# Add this function to handle JSON serialization for complex structures
def _prepare_metadata_for_storage(metadata):
    """
    Prepares metadata for storage by serializing complex structures to JSON strings
    and replacing None values with appropriate defaults since ChromaDB can't handle None values.
    """
    processed_metadata = metadata.copy()
    
    # Replace None values with appropriate defaults
    for key in processed_metadata:
        if processed_metadata[key] is None:
            # Use empty string as default for None values
            processed_metadata[key] = ""
    
    # Fields that might contain complex structures
    complex_fields = [
        'mandatory_testing', 'recommended_testing', 'recommendations',
        'component_analysis', 'impact'
    ]
    
    for field in complex_fields:
        if field in processed_metadata:
            if processed_metadata[field] is None:
                # Use empty dict as default for None complex fields
                processed_metadata[field] = "{}"
            elif isinstance(processed_metadata[field], (dict, list)):
                # Ensure no None values in nested structures
                if isinstance(processed_metadata[field], dict):
                    for k in processed_metadata[field]:
                        if processed_metadata[field][k] is None:
                            processed_metadata[field][k] = ""
                # Serialize to JSON string
                processed_metadata[field] = json.dumps(processed_metadata[field])
    
    return processed_metadata

# Update function signature to accept project_name
def add_assessment(collection, requirement_text, embedding, risk, reasoning, recommendations, impact, project_name):
    """Adds a new assessment to the ChromaDB collection."""
    doc_id = str(uuid.uuid4())
    timestamp = int(time.time())
    
    logger.info(f"Adding new assessment with ID: {doc_id}, Project: {project_name}, Risk: {risk}")
    
    # Ensure no values are None (ChromaDB doesn't accept None values)
    metadata = {
        "requirement_text": requirement_text or "",
        "risk": risk or "",
        "reasoning": reasoning or "",
        "recommendations": recommendations or {},
        "impact": impact or {},
        "project_name": project_name or "Unnamed Project",
        "status": "Pending",
        "comments": "",
        "timestamp": timestamp,
        "id": doc_id
    }
    
    # Log for debugging
    logger.debug(f"Preparing metadata for storage with keys: {list(metadata.keys())}")
    
    # Serialize complex structures before storage and handle None values
    processed_metadata = _prepare_metadata_for_storage(metadata)
    
    # Double check no None values exist
    for key, value in processed_metadata.items():
        if value is None:
            logger.warning(f"None value detected for key {key} after processing. Replacing with empty string.")
            processed_metadata[key] = ""
    
    try:
        logger.debug(f"Adding document with metadata keys: {list(processed_metadata.keys())}")
        try:
            collection.add(
                documents=[requirement_text or ""],  # Ensure document is not None
                embeddings=[embedding],
                metadatas=[processed_metadata],
                ids=[doc_id]
            )
            logger.info(f"Assessment added successfully with ID: {doc_id}")
            
            # Log detailed info at debug level
            logger.debug(f"Assessment details - ID: {doc_id}, Text length: {len(requirement_text or '')}, "
                        f"Embedding dimensions: {len(embedding)}")
            
            return doc_id
            
        except chromadb_errors.IDAlreadyExistsError:
            # Generate a new UUID and try again
            new_doc_id = str(uuid.uuid4())
            logger.warning(f"ID collision detected. Retrying with new ID: {new_doc_id}")
            processed_metadata['id'] = new_doc_id
            
            collection.add(
                documents=[requirement_text or ""],
                embeddings=[embedding],
                metadatas=[processed_metadata],
                ids=[new_doc_id]
            )
            logger.info(f"Assessment added successfully with alternate ID: {new_doc_id}")
            return new_doc_id
            
        except chromadb_errors.DuplicateIDError as e:
            logger.error(f"Duplicate ID error: {str(e)}")
            raise Exception(f"Document with this ID already exists: {str(e)}")
            
        except chromadb_errors.InvalidDimensionException as e:
            logger.error(f"Invalid embedding dimensions: {str(e)}")
            raise Exception(f"Invalid embedding format: {str(e)}")
            
        except chromadb_errors.ChromaError as e:
            logger.error(f"ChromaDB error: {str(e)}")
            raise Exception(f"Database error: {str(e)}")
            
    except Exception as e:
        logger.error(f"Error adding assessment to Chroma: {str(e)}")
        # Log the exact metadata that caused the error
        logger.error(f"Problematic metadata: {json.dumps(processed_metadata)}")
        return None

# Add function to deserialize complex JSON structures
def _deserialize_complex_fields(metadata):
    """
    Deserializes any JSON strings in metadata fields that should be complex structures
    """
    if metadata is None:
        return metadata
        
    result = metadata.copy()
    complex_fields = [
        'mandatory_testing', 'recommended_testing', 'recommendations',
        'component_analysis', 'impact'
    ]
    
    for field in complex_fields:
        if field in result and isinstance(result[field], str):
            try:
                # Check if it looks like a JSON object or array
                if (result[field].startswith('{') and result[field].endswith('}')) or \
                   (result[field].startswith('[') and result[field].endswith(']')):
                    result[field] = json.loads(result[field])
                    # Debug when component_analysis is found
                    if field == 'component_analysis':
                        logger.info(f"Successfully deserialized component_analysis: {list(result[field].keys()) if isinstance(result[field], dict) else 'not a dict'}")
            except json.JSONDecodeError:
                # If not valid JSON, keep as string
                logger.warning(f"Failed to deserialize field '{field}' - keeping as string")
                if field == 'component_analysis':
                    # Log the problematic string value (truncated for log size)
                    value_preview = result[field][:100] + "..." if len(result[field]) > 100 else result[field]
                    logger.error(f"JSON decode error for component_analysis: {value_preview}")
    
    return result

# --- Collection Statistics and Management ---

# Define the log_operation_stats function
def log_operation_stats(operation_name, start_time, success, details=None):
    """
    Logs statistics about an operation.
    
    Args:
        operation_name (str): Name of the operation.
        start_time (float): Start time of the operation.
        success (bool): Whether the operation was successful.
        details (dict): Additional details about the operation.
    """
    elapsed_time = time.time() - start_time
    status = "Success" if success else "Failure"
    details_str = json.dumps(details) if details else "{}"
    logger.info(f"Operation '{operation_name}' completed with status: {status}. "
                f"Elapsed time: {elapsed_time:.2f}s. Details: {details_str}")
def get_collection_stats(collection):
    """
    Returns statistics about the collection for monitoring purposes.
    
    Args:
        collection: The ChromaDB collection object.
        
    Returns:
        Dictionary with statistics about the collection.
    """
    try:
        # Get all items count
        count = collection.count()
        
        # Get risk distribution if available
        results = collection.get(include=['metadatas'])
        
        stats = {
            "total_entries": count,
            "risk_distribution": {
                "High": 0,
                "Medium": 0, 
                "Low": 0,
                "Unknown": 0
            },
            "status_distribution": {
                "Approved": 0,
                "Rejected": 0,
                "Pending": 0,
                "Other": 0
            },
            "last_updated": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        }
        
        # Calculate distributions
        if results and results.get('metadatas'):
            for metadata in results['metadatas']:
                # Risk distribution
                risk = metadata.get('risk', 'Unknown')
                if risk in stats["risk_distribution"]:
                    stats["risk_distribution"][risk] += 1
                else:
                    stats["risk_distribution"]["Unknown"] += 1
                    
                # Status distribution
                status = metadata.get('status', 'Other')
                if status in stats["status_distribution"]:
                    stats["status_distribution"][status] += 1
                else:
                    stats["status_distribution"]["Other"] += 1
        
        return stats
    except Exception as e:
        logger.error(f"Error getting collection stats: {e}")
        return {"error": str(e), "total_entries": 0}

# Add function to perform semantic search with keywords
def semantic_search(collection, query_text, api_key, n_results=DEFAULT_N_RESULTS, custom_threshold=DEFAULT_SIMILARITY_THRESHOLD):
    """
    Performs semantic search using natural language query instead of embeddings.
    
    Args:
        collection: The ChromaDB collection object.
        query_text: The search query in natural language.
        api_key: OpenAI API key for embedding generation.
        n_results: Maximum number of results to return.
        custom_threshold: Similarity threshold.
        
    Returns:
        List of search results with similarity scores.
    """
    if not query_text or not api_key:
        return None
    
    try:
        # Generate embedding for the query text
        query_embedding = generate_embedding(query_text, api_key)
        
        # Use the existing find_similar_requirements function
        return find_similar_requirements(
            collection,
            query_embedding,
            n_results=n_results,
            custom_threshold=custom_threshold
        )
    except Exception as e:
        logger.error(f"Error in semantic search: {e}")
        return None

# Add functionality to export/backup vector database
def export_collection_data(collection, output_file="chroma_backup.json"):
    """
    Exports all data from the collection to a JSON file as backup.
    
    Args:
        collection: The ChromaDB collection object.
        output_file: Path to save the backup file.
        
    Returns:
        Boolean indicating success or failure.
    """
    try:
        # Get all data
        results = collection.get(include=['metadatas', 'documents', 'embeddings'])
        
        # Prepare export data
        export_data = {
            "ids": results.get('ids', []),
            "metadatas": results.get('metadatas', []),
            "documents": results.get('documents', []),
            "embeddings": results.get('embeddings', []),
            "export_timestamp": int(time.time()),
            "export_date": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        }
        
        # Save to file
        with open(output_file, 'w') as f:
            import json
            json.dump(export_data, f)
        
        logger.info(f"Successfully exported {len(export_data['ids'])} records to {output_file}")
        return True
    except Exception as e:
        logger.error(f"Error exporting collection data: {e}")
        return False

# Renamed function and updated to handle generic status
def update_assessment_status(collection, doc_id, new_status, comments):
    """Updates the status and comments for a specific assessment."""
    if new_status not in ["Approved", "Rejected", "Pending"]: # Basic validation
        logger.error(f"Invalid status '{new_status}' provided.")
        return False
    try:
        # Chroma doesn't have a direct 'update metadata' for a single field easily.
        # We get the existing record, update metadata, and use 'update' (or upsert).
        existing_record = collection.get(ids=[doc_id], include=['metadatas', 'embeddings', 'documents'])

        if not existing_record or not existing_record.get('ids'):
            logger.error(f"Document with ID {doc_id} not found for update.")
            return False

        # Assuming only one record is returned for the ID
        current_metadata = existing_record['metadatas'][0]
        current_embedding = existing_record['embeddings'][0]
        current_document = existing_record['documents'][0]

        # Update the metadata
        current_metadata['status'] = new_status # Use the new status field
        current_metadata['comments'] = comments if comments else "" # Ensure comments is not None
        if 'approved' in current_metadata: # Remove old 'approved' field if it exists
            del current_metadata['approved']
            
        # Make sure to serialize complex structures before storing and handle None values
        processed_metadata = _prepare_metadata_for_storage(current_metadata)

        # Double check no None values exist
        for key, value in processed_metadata.items():
            if value is None:
                logger.warning(f"None value detected for key {key} in update. Replacing with empty string.")
                processed_metadata[key] = ""

        # Use upsert to update the record
        collection.upsert(
            ids=[doc_id],
            embeddings=[current_embedding],
            documents=[current_document or ""],  # Ensure document is not None
            metadatas=[processed_metadata]
        )
        logger.info(f"Updated status to '{new_status}' for ID: {doc_id}")
        return True
    except Exception as e:
        logger.error(f"Error updating assessment status in Chroma: {str(e)}")
        return False

# Update get_all_assessments to deserialize complex fields
def get_all_assessments(collection):
    """Retrieves all assessments from the collection."""
    try:
        # Get all items. Be cautious with very large collections.
        # Consider pagination or filtering if performance becomes an issue.
        start_time = time.time()
        results = collection.get(include=['metadatas']) # Removed 'ids' from include
        assessments = []
        if results and results.get('ids'): # Check if 'ids' key exists in the result
            for i, doc_id in enumerate(results['ids']):
                 # Ensure metadatas list is long enough
                 if i < len(results.get('metadatas', [])):
                     metadata = results['metadatas'][i]
                     
                     # Deserialize any complex fields
                     metadata = _deserialize_complex_fields(metadata)
                     
                 else:
                     metadata = {} # Handle case where metadata might be missing unexpectedly

                 # Add the ID to the metadata dict if it's not already there
                 if metadata is not None and 'id' not in metadata:
                     metadata['id'] = doc_id
                 assessments.append(metadata)
        # Sort by timestamp descending (newest first)
        assessments.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        
        # Log operation statistics
        log_operation_stats("fetch_all_assessments", start_time, True, {"count": len(assessments)})
        return assessments
    except Exception as e:
        logger.error(f"Error retrieving all assessments from Chroma: {str(e)}")
        log_operation_stats("fetch_all_assessments", start_time, False, {"error": str(e)})
        return []

# Update find_similar_requirements to deserialize complex fields in results
def find_similar_requirements(collection, embedding, n_results=DEFAULT_N_RESULTS, custom_threshold=DEFAULT_SIMILARITY_THRESHOLD):
    """
    Finds similar requirements in the collection based on embedding.
    Args:
        collection: The ChromaDB collection object.
        embedding: The query embedding.
        n_results (int): The number of results to retrieve from ChromaDB.
        custom_threshold (float): The distance threshold for similarity (distance < threshold).
        
    Returns:
        List of dictionaries containing similar requirements with metadata, distance scores,
        and calculated similarity percentages.
    """
    if embedding is None:
        logger.warning("Null embedding provided to find_similar_requirements")
        return None
    
    logger.info(f"Searching for similar requirements with threshold: {custom_threshold}, max results: {n_results}")
    start_time = time.time()
    
    try:
        # Request more results than needed for better filtering
        retrieve_count = min(n_results * 3, 20)
        
        # Attempt the database query with better error handling
        try:
            results = collection.query(
                query_embeddings=[embedding],
                n_results=retrieve_count,
                include=['metadatas', 'distances', 'documents']
            )
        except chromadb_errors.NoIndexException as e:
            logger.error(f"Database index not found: {str(e)}")
            raise Exception(f"Database index error: {str(e)}. The vector database may need to be rebuilt.")
        except chromadb_errors.ChromaError as e:
            logger.error(f"ChromaDB error during query: {str(e)}")
            raise Exception(f"Database query error: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error during database query: {str(e)}")
            raise Exception(f"Error querying database: {str(e)}")

        # Process results
        similar_docs = []
        if results and results.get('ids') and results['ids'][0]:
            for i, doc_id in enumerate(results['ids'][0]):
                distance = results['distances'][0][i]
                if distance < custom_threshold:
                    metadata = results['metadatas'][0][i]
                    
                    # Deserialize complex fields in metadata
                    metadata = _deserialize_complex_fields(metadata)
                    
                    document = results['documents'][0][i] if 'documents' in results else ""
                    similarity_percentage = round((1 - distance) * 100, 2)
                    
                    similar_docs.append({
                        "id": doc_id,
                        "distance": distance,
                        "similarity_percentage": similarity_percentage,
                        "metadata": metadata,
                        "document": document[:250] + "..." if len(document) > 250 else document
                    })
            
            similar_docs.sort(key=lambda x: x['distance'])
            similar_docs = similar_docs[:n_results]
            
            for doc in similar_docs:
                if doc['similarity_percentage'] >= 90:
                    doc['match_quality'] = "Strong match"
                elif doc['similarity_percentage'] >= 75:
                    doc['match_quality'] = "Good match"
                elif doc['similarity_percentage'] >= 60:
                    doc['match_quality'] = "Moderate match"
                else:
                    doc['match_quality'] = "Weak match"
        
        elapsed = time.time() - start_time
        found_count = len(similar_docs)
        
        logger.info(f"Search completed in {elapsed:.2f}s. Found {found_count} similar documents out of {retrieve_count} retrieved")
        if found_count > 0:
            logger.debug(f"Top match similarity: {similar_docs[0]['similarity_percentage']}%, match quality: {similar_docs[0]['match_quality']}")
        
        return similar_docs
    except Exception as e:
        logger.error(f"Error querying Chroma for similar requirements: {str(e)}")
        return None

# Add database reconnection logic
# Define a decorator for database operation retry
def with_database_reconnection(max_retries=3):
    """
    Decorator that adds reconnection logic to database operations.
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    retries += 1
                    logger.warning(f"Database operation failed: {str(e)}. Attempt {retries} of {max_retries}.")
                    if retries >= max_retries:
                        logger.error(f"Maximum retries ({max_retries}) exceeded for database operation.")
                        raise
                    # Exponential backoff before retry
                    time.sleep(2 ** retries)
                    # Try to refresh the ChromaDB client if possible
                    try:
                        global client
                        logger.info("Attempting to reinitialize ChromaDB client...")
                        client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
                        logger.info("ChromaDB client reinitialized successfully")
                    except Exception as client_error:
                        logger.error(f"Failed to reinitialize ChromaDB client: {str(client_error)}")
            return None  # Should not reach here, but just in case
        return wrapper
    return decorator

# Apply the reconnection decorator to critical database functions
@with_database_reconnection()
def get_or_create_collection_with_retry(api_key):
    """
    Gets or creates the ChromaDB collection with automatic reconnection logic.
    Wraps the original get_or_create_collection function with retry capabilities.
    """
    retries = 0
    max_retries = 3
    last_error = None
    
    while retries < max_retries:
        try:
            return get_or_create_collection(api_key)
        except (chromadb_errors.ChromaError, ConnectionError) as e:
            last_error = e
            retries += 1
            logger.warning(f"Failed to get/create collection (attempt {retries}/{max_retries}): {str(e)}")
            if retries >= max_retries:
                break
            # Exponential backoff
            time.sleep(2 ** retries)
            
    # If we get here, we've exhausted retries
    logger.error(f"Failed to get/create collection after {max_retries} attempts. Last error: {str(last_error)}")
    raise last_error
