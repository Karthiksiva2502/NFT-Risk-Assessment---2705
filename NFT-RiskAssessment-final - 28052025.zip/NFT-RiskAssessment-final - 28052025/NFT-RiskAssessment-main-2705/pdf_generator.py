# Function to generate PDF reports using FPDF2
from fpdf import FPDF
import time
import uuid
import re

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Requirement Risk Assessment Report', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.set_font('Arial', '', 10)
        # Use multi_cell for automatic line breaks
        self.multi_cell(0, 5, body)
        self.ln()
    
    # Add missing methods
    def setup_document(self):
        """Initialize the document with basic settings"""
        self.add_page()
        self.set_auto_page_break(auto=True, margin=15)
        self.set_font("Arial", "B", 16)
    
    def add_heading(self, text, size=14):
        """Add a heading with specified font size"""
        self.set_font("Arial", "B", size)
        self.cell(0, 10, text, 0, 1)
        self.ln(2)
    
    def add_title(self, title):
        """Add main title to the document"""
        self.set_font("Arial", "B", 18)
        self.cell(0, 10, title, 0, 1, 'C')
        self.ln(10)
    
    def add_text(self, text):
        """Add regular text paragraph"""
        # Clean up text to handle potential encoding issues
        if text:
            text = re.sub(r'\n\s*\n', '\n\n', text)  # Normalize multiple newlines
            text = text.encode('latin-1', 'replace').decode('latin-1')  # Handle encoding
        else:
            text = "N/A"
            
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, text)
        self.ln(5)
    
    def add_summary_item(self, label, value):
        """Add a summary item with label and value"""
        self.set_font("Arial", "B", 10)
        self.cell(40, 8, label, 0, 0)
        self.set_font("Arial", "", 10)
        self.cell(0, 8, str(value), 0, 1)
    
    def get_pdf_bytes(self):
        """Return the PDF as bytes"""
        # FPDF's output with dest='S' might return bytearray, convert to bytes explicitly
        output = self.output(dest='S')
        # Ensure we return bytes, not bytearray
        if isinstance(output, bytearray):
            return bytes(output)
        return output

    def add_assessment_section(self, title, content):
        """Add a section with title and content to the PDF."""
        self.add_heading(title, 14)
        
        # Handle content that might be a dictionary (for structured JSON responses)
        if isinstance(content, dict):
            # Convert dictionary to formatted string
            formatted_content = ""
            for key, value in content.items():
                if isinstance(value, dict):
                    # Handle nested dictionaries
                    formatted_content += f"{key}:\n"
                    for sub_key, sub_value in value.items():
                        formatted_content += f"  • {sub_key}: {sub_value}\n"
                    formatted_content += "\n"
                else:
                    formatted_content += f"{key}: {value}\n\n"
            content = formatted_content
    
        # Now that content is guaranteed to be a string, we can use string methods
        content = str(content)  # Ensure it's a string
        content_cleaned = content.replace('\u2022', '-').encode('latin-1', 'replace').decode('latin-1')
        
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, content_cleaned)
        self.ln(5)


def generate_pdf_report(assessment_data):
    """Generate a PDF report from the assessment data."""
    pdf = PDF()
    pdf.setup_document()
    
    # Add title
    pdf.add_title("Non-Functional Requirement Risk Assessment Report")
    
    # Add summary section
    pdf.add_heading("Assessment Summary", 16)
    pdf.add_summary_item("Assessment ID:", assessment_data.get('id', 'N/A'))
    pdf.add_summary_item("Project:", assessment_data.get('project_name', 'N/A'))
    pdf.add_summary_item("Risk Level:", assessment_data.get('risk', 'N/A'))
    pdf.add_summary_item("Status:", assessment_data.get('status', 'Pending'))
    
    # Add timestamp if available
    timestamp = assessment_data.get('timestamp')
    if timestamp:
        date_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
        pdf.add_summary_item("Assessment Date:", date_str)
    
    # Add requirement section
    pdf.add_heading("Requirement", 16)
    requirement_text = assessment_data.get('requirement_text', 'N/A')
    pdf.add_text(requirement_text)
    
    # Add assessment sections
    pdf.add_assessment_section("Reasoning:", assessment_data.get('reasoning', 'N/A'))
    
    # Handle both old and new formats for all sections
    if 'mandatory_testing' in assessment_data:
        pdf.add_assessment_section("Mandatory Testing (Centrica Services):", assessment_data.get('mandatory_testing', 'N/A'))
    
    if 'recommended_testing' in assessment_data:
        pdf.add_assessment_section("Recommended Testing:", assessment_data.get('recommended_testing', 'N/A'))
    elif 'recommendations' in assessment_data:
        pdf.add_assessment_section("Recommended Testing:", assessment_data.get('recommendations', 'N/A'))
    
    if 'component_analysis' in assessment_data:
        pdf.add_assessment_section("Component Analysis:", assessment_data.get('component_analysis', 'N/A'))
    
    pdf.add_assessment_section("Impact of Not Testing:", assessment_data.get('impact', 'N/A'))
    
    # Add reviewer comments if available
    comments = assessment_data.get('comments')
    if comments and comments.strip():
        pdf.add_assessment_section("Reviewer Comments:", comments)
    
    # Get the PDF content as bytes
    pdf_bytes = pdf.get_pdf_bytes()
    
    # Ensure we're returning bytes, not bytearray for Streamlit compatibility
    if isinstance(pdf_bytes, bytearray):
        pdf_bytes = bytes(pdf_bytes)
    
    return pdf_bytes

# Example Usage (for testing)
if __name__ == '__main__':
    dummy_data = {
        'requirement_text': "The system must allow users to upload profile pictures.",
        'context': {
            'project_type': 'Enhancement', 'sensitive_data': 'Yes (PII)',
            'user_volume': 'Medium (1000 concurrent)', 'performance': 'High (sub-second uploads)',
            'accessibility': 'Yes (WCAG AA)', 'integrations': 'No', 'uptime': '99.9%'
        },
        'risk': 'Medium',
        'reasoning': 'Handles PII (profile pictures) and has performance requirements. Needs security and load testing.',
        'recommendations': '- Security Testing: Scan for vulnerabilities related to image uploads.\n- Performance Testing: Verify upload times under load.\n- Accessibility Testing: Ensure upload controls are accessible.',
        'impact': 'Failure to test could lead to data exposure or poor user experience during uploads.',
        'approved': True,
        'comments': 'Approved after verifying security scan results.',
        'timestamp': int(time.time()) - 86400, # Yesterday
        'id': str(uuid.uuid4())
    }
    pdf_bytes = generate_pdf_report(dummy_data)
    with open("sample_report.pdf", "wb") as f:
        f.write(pdf_bytes)
    print("Sample PDF report generated: sample_report.pdf")
