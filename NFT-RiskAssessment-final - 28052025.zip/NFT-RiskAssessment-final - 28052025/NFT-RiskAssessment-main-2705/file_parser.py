# Functions for reading .txt and .docx files
import docx
import io
import pandas as pd

def read_txt(file):
    """Reads text from an uploaded .txt file."""
    return file.getvalue().decode("utf-8")

def read_docx(file):
    """Reads text from an uploaded .docx file."""
    doc = docx.Document(io.BytesIO(file.getvalue()))
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    return '\n'.join(full_text)

def read_csv(file):
    """Reads requirement text from an uploaded CSV file."""
    try:
        df = pd.read_csv(io.BytesIO(file.getvalue()))
        # Look for requirement text column with various possible names
        possible_column_names = ['requirement_text', 'requirement', 'Requirement Text', 'Requirement', 'requirements', 'Requirements']
        found_column = None
        
        for col_name in possible_column_names:
            if col_name in df.columns:
                found_column = col_name
                break
                
        if found_column is None:
            return None, "Could not find a column named 'requirement_text' or similar in the CSV."
            
        # Extract requirements and filter out empty ones
        requirements = df[found_column].astype(str).tolist()
        requirements = [req for req in requirements if req and req.strip() and req.lower() != 'nan']
        
        if not requirements:
            return None, "No valid requirements found in the CSV file."
            
        return requirements, None
    except Exception as e:
        return None, f"Error processing CSV file: {str(e)}"

def parse_file(uploaded_file):
    """Parses the uploaded file based on its type."""
    if uploaded_file.type == "text/plain":
        return read_txt(uploaded_file), None
    elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        return read_docx(uploaded_file), None
    elif uploaded_file.type == "text/csv":
        return read_csv(uploaded_file)  # This returns (requirements_list, error_msg)
    else:
        return None, f"Unsupported file type: {uploaded_file.type}"
