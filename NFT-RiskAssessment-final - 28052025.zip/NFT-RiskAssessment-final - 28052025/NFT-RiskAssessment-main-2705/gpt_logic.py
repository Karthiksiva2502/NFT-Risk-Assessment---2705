# Enhanced GPT Logic for NFT Risk Assessment Tool
# Functions for composing prompts and interacting with the OpenAI API with improved accuracy and validation

import openai
import json
import traceback
import re
import time
from typing import Dict, List, Optional, Any
from datetime import datetime

# --- Constants ---
GPT_MODEL = "gpt-4o"
FALLBACK_MODEL = "gpt-4"  # Fallback if primary model fails
MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds

# Risk validation constants
VALID_RISK_LEVELS = ["High", "Medium", "Low"]
REQUIRED_RESPONSE_KEYS = ["risk", "reasoning", "mandatory_testing", "recommended_testing", "component_analysis", "impact"]

# Testing categories for validation
MANDATORY_TESTING_CATEGORIES = [
    "Performance Testing", "Operational Acceptance Testing", "Single-user Performance Testing"
]

RECOMMENDED_TESTING_CATEGORIES = [
    "Security Testing", "Scalability Testing", "Reliability Testing", "Usability Testing",
    "Compatibility Testing", "Data Integrity Testing", "Integration Testing", "Accessibility Testing",
    "Compliance Testing", "Regression Testing"
]

# Advanced validation constants for enhanced quality assurance
ADVANCED_VALIDATION_WEIGHTS = {
    "logical_consistency": 0.25,
    "completeness_analysis": 0.20,
    "risk_justification": 0.20,
    "testing_adequacy": 0.15,
    "business_alignment": 0.10,
    "technical_feasibility": 0.10
}

QUALITY_THRESHOLDS = {
    "excellent": 0.90,
    "good": 0.75,
    "acceptable": 0.60,
    "needs_improvement": 0.45
}

class RiskAssessmentValidator:
    """Validates and enhances GPT responses for consistency and completeness."""
    
    @staticmethod
    def validate_risk_level(risk: str) -> tuple[bool, str]:
        """Validates risk level and provides correction if needed."""
        if not risk or risk not in VALID_RISK_LEVELS:
            return False, f"Invalid risk level '{risk}'. Must be one of: {VALID_RISK_LEVELS}"
        return True, ""
    
    @staticmethod
    def validate_reasoning_quality(reasoning: str, requirement_text: str) -> tuple[bool, str, str]:
        """Validates reasoning quality and provides enhanced reasoning if needed."""
        if not reasoning or len(reasoning.strip()) < 50:
            return False, "Reasoning too brief or missing", ""
        
        # Check if reasoning mentions key aspects
        key_aspects = ["performance", "security", "integration", "data", "user", "business"]
        mentioned_aspects = [aspect for aspect in key_aspects if aspect.lower() in reasoning.lower()]
        
        if len(mentioned_aspects) < 2:
            enhanced_reasoning = f"{reasoning}\n\nAdditional Analysis: The assessment considers multiple risk dimensions including technical complexity, business impact, and operational challenges based on the requirement: '{requirement_text[:100]}...'"
            return True, "Reasoning enhanced with additional context", enhanced_reasoning
        
        return True, "", reasoning
    
    @staticmethod
    def validate_testing_recommendations(mandatory_testing: Dict, recommended_testing: Dict) -> tuple[bool, str, Dict, Dict]:
        """Validates and enhances testing recommendations."""
        issues = []
        enhanced_mandatory = mandatory_testing.copy()
        enhanced_recommended = recommended_testing.copy()
        
        # Ensure mandatory testing has required categories
        for category in MANDATORY_TESTING_CATEGORIES:
            if category not in enhanced_mandatory:
                enhanced_mandatory[category] = {
                    "General": f"Perform {category.lower()} to ensure system reliability and performance standards are met."
                }
                issues.append(f"Added missing mandatory testing: {category}")
        
        # Validate testing descriptions are detailed enough
        for category, tests in enhanced_mandatory.items():
            for component, description in tests.items():
                if len(description) < 30:
                    enhanced_mandatory[category][component] = f"{description} This testing is critical to validate system behavior under expected conditions and ensure compliance with requirements."
                    issues.append(f"Enhanced description for {category} - {component}")
        
        for category, tests in enhanced_recommended.items():
            for component, description in tests.items():
                if len(description) < 30:
                    enhanced_recommended[category][component] = f"{description} This testing helps identify potential issues and ensures robust system performance across various scenarios."
                    issues.append(f"Enhanced description for {category} - {component}")
        
        return len(issues) == 0, "; ".join(issues), enhanced_mandatory, enhanced_recommended
    
    @staticmethod
    def validate_component_analysis(component_analysis: Dict, requirement_text: str) -> tuple[bool, str, Dict]:
        """Validates and enhances component analysis."""
        if not component_analysis:
            # Extract potential components from requirement text
            components = RiskAssessmentValidator._extract_components_from_text(requirement_text)
            enhanced_analysis = {}
            
            for component in components:
                enhanced_analysis[component] = {
                    "Performance Testing": f"Validate {component.lower()} performance under expected load conditions.",
                    "Security Testing": f"Ensure {component.lower()} meets security requirements and standards."
                }
            
            if not enhanced_analysis:
                enhanced_analysis = {
                    "System": {
                        "Performance Testing": "Validate overall system performance under expected conditions.",
                        "Reliability Testing": "Ensure system reliability and fault tolerance."
                    }
                }
            
            return False, "Component analysis was missing and has been generated", enhanced_analysis
        
        return True, "", component_analysis
    
    @staticmethod
    def _extract_components_from_text(text: str) -> List[str]:
        """Extracts potential system components from requirement text."""
        # Common component keywords
        component_patterns = [
            r'\b(API|api)\b', r'\b(database|DB|db)\b', r'\b(UI|user interface)\b',
            r'\b(backend|back-end)\b', r'\b(frontend|front-end)\b', r'\b(mobile app|application)\b',
            r'\b(web service|service)\b', r'\b(microservice)\b', r'\b(server)\b'
        ]
        
        components = set()
        text_lower = text.lower()
        
        for pattern in component_patterns:
            matches = re.findall(pattern, text_lower, re.IGNORECASE)
            for match in matches:
                if 'api' in match.lower():
                    components.add('API')
                elif 'database' in match.lower() or 'db' in match.lower():
                    components.add('Database')
                elif 'ui' in match.lower() or 'interface' in match.lower():
                    components.add('User Interface')
                elif 'app' in match.lower():
                    components.add('Application')
                elif 'service' in match.lower():
                    components.add('Service')
                elif 'server' in match.lower():
                    components.add('Server')
        
        return list(components) if components else ['System']

class EnhancedPromptComposer:
    """Enhanced prompt composition with context analysis and validation."""
    
    @staticmethod
    def analyze_context_quality(context: Dict) -> tuple[float, List[str]]:
        """Analyzes context quality and suggests improvements."""
        quality_score = 0.0
        suggestions = []
        total_possible = 10  # Maximum quality indicators
        
        # Check for essential context elements
        essential_elements = [
            ('performance requirements', ['performance', 'response time', 'load', 'users']),
            ('security requirements', ['security', 'authentication', 'authorization', 'compliance']),
            ('integration details', ['integration', 'api', 'third-party', 'external']),
            ('business criticality', ['critical', 'business', 'impact', 'priority']),
            ('technical constraints', ['constraint', 'limitation', 'requirement', 'standard'])
        ]
        
        for element_name, keywords in essential_elements:
            found = False
            for key, value in context.items():
                if any(keyword.lower() in str(value).lower() for keyword in keywords):
                    found = True
                    quality_score += 2
                    break
            
            if not found:
                suggestions.append(f"Consider providing {element_name} for more accurate assessment")
        
        # Bonus points for detailed context
        total_context_length = sum(len(str(v)) for v in context.values() if v)
        if total_context_length > 500:
            quality_score += 1
        elif total_context_length < 100:
            suggestions.append("Provide more detailed context for better assessment accuracy")
        
        return min(quality_score / total_possible, 1.0), suggestions
    
    @staticmethod
    def compose_enhanced_prompt(requirement_text: str, context: Dict, similar_requirements: Optional[List] = None) -> str:
        """Composes an enhanced prompt with validation and context analysis."""
        
        # Analyze context quality
        context_quality, context_suggestions = EnhancedPromptComposer.analyze_context_quality(context)
        
        prompt = f"""
You are an expert software risk analyst specializing in non-functional requirements assessment. Your task is to provide a comprehensive, accurate, and actionable risk assessment.

**CRITICAL INSTRUCTIONS:**
- Provide detailed, specific analysis based on the actual requirement content
- Ensure all testing recommendations are practical and implementable
- Consider real-world constraints and industry best practices
- Be specific about tools, methods, and approaches
- Focus on non-functional risks that could impact system reliability, performance, security, and user experience

**Requirement to Analyze:**
```
{requirement_text}
```

**Context Quality Score: {context_quality:.1%}**
"""

        # Add context section with quality indicators
        if context:
            prompt += "\n**Context Information:**\n"
            for key, value in context.items():
                if value and str(value).strip() and str(value).lower() != 'n/a':
                    if key == "AI Assistant Gathered Information":
                        prompt += f"\n**AI-Gathered Information:**\n{value}\n"
                    else:
                        prompt += f"- **{key}**: {value}\n"
        else:
            prompt += "\n**Context Information:** Limited context provided. Assessment based on requirement text analysis.\n"
        
        if context_suggestions:
            prompt += f"\n**Note:** For future assessments, consider providing: {'; '.join(context_suggestions)}\n"

        # Add similar requirements analysis
        if similar_requirements:
            prompt += "\n**Historical Analysis (Similar Requirements):**\n"
            for i, req in enumerate(similar_requirements[:3]):  # Limit to top 3
                past_meta = req.get('metadata', {})
                prompt += f"\n{i+1}. **Previous Assessment:**\n"
                prompt += f"   - Requirement: {past_meta.get('requirement_text', 'N/A')[:100]}...\n"
                prompt += f"   - Risk Level: {past_meta.get('risk', 'N/A')}\n"
                prompt += f"   - Key Reasoning: {past_meta.get('reasoning', 'N/A')[:200]}...\n"
                prompt += f"   - Outcome: {past_meta.get('approved', 'Unknown')}\n"
            
            prompt += "\n**Learning from History:** Use these past assessments to inform your analysis, but ensure your assessment is tailored to the current requirement's unique characteristics.\n"

        prompt += f"""

**ASSESSMENT FRAMEWORK:**

### **Risk Classification:**
Determine risk level (High/Medium/Low) based on:
- **Technical Complexity**: Integration points, performance requirements, scalability needs
- **Business Impact**: Criticality to operations, user experience implications, financial impact
- **Implementation Challenges**: Resource requirements, timeline constraints, dependencies
- **Operational Risk**: Monitoring needs, maintenance complexity, failure scenarios

### **Mandatory Testing Analysis:**
For each mandatory testing type, provide:
- **Specific rationale** tied to the requirement
- **Detailed methodology** including tools and approaches
- **Success criteria** and measurable outcomes
- **Risk mitigation** achieved through the testing

### **Recommended Testing Strategy:**
For each recommended testing type:
- **Risk-based justification** for the testing need
- **Implementation approach** with specific tools/methods
- **Expected outcomes** and benefits
- **Priority level** (Critical/Important/Nice-to-have)

### **Component-Specific Analysis:**
Identify key system components and provide:
- **Component-specific risks** and vulnerabilities
- **Targeted testing strategies** for each component
- **Integration testing** requirements between components
- **Performance benchmarks** and acceptance criteria

### **Impact Assessment:**
For each testing category, specify:
- **Technical risks** of not performing the testing
- **Business consequences** including financial and operational impact
- **User experience implications** and satisfaction risks
- **Compliance and regulatory** risks where applicable

**RESPONSE FORMAT:**
Provide your response in the following JSON structure. Ensure all sections are comprehensive and actionable:

```json
{{
  "risk": "High|Medium|Low",
  "reasoning": "Comprehensive analysis of why this risk level was assigned, including technical, business, and operational factors. Minimum 200 characters with specific references to the requirement.",
  "confidence_score": 0.85,
  "assessment_metadata": {{
    "context_quality": {context_quality:.2f},
    "analysis_depth": "comprehensive|standard|basic",
    "similar_cases_used": {len(similar_requirements) if similar_requirements else 0}
  }},
  "mandatory_testing": {{
    "Performance Testing": {{
      "API": "Detailed description of API performance testing approach, tools (e.g., JMeter, LoadRunner), metrics, and acceptance criteria.",
      "System": "System-level performance testing methodology with specific load scenarios and monitoring approaches."
    }},
    "Operational Acceptance Testing": {{
      "Deployment": "Deployment validation procedures, rollback strategies, and operational readiness verification.",
      "Monitoring": "Monitoring setup validation, alerting configuration, and incident response procedures."
    }},
    "Single-user Performance Testing": {{
      "User Experience": "Individual user experience testing, response time validation, and usability verification."
    }}
  }},
  "recommended_testing": {{
    "Security Testing": {{
      "priority": "Critical|Important|Nice-to-have",
      "approach": "Specific security testing methodology including penetration testing, vulnerability scanning, and compliance validation.",
      "tools": ["OWASP ZAP", "Burp Suite", "Nessus"],
      "deliverables": "Security assessment report, vulnerability remediation plan, compliance verification."
    }},
    "Scalability Testing": {{
      "priority": "Critical|Important|Nice-to-have",
      "approach": "Load scaling methodology, user simulation, and infrastructure stress testing.",
      "tools": ["JMeter", "LoadRunner", "Artillery"],
      "deliverables": "Scalability assessment, bottleneck analysis, capacity planning recommendations."
    }}
  }},
  "component_analysis": {{
    "API": {{
      "risks": ["Specific risk 1", "Specific risk 2"],
      "testing_strategy": "Component-specific testing approach with tools and methodologies.",
      "success_criteria": "Measurable acceptance criteria and performance benchmarks."
    }},
    "Database": {{
      "risks": ["Data integrity risk", "Performance degradation risk"],
      "testing_strategy": "Database testing approach including performance, integrity, and recovery testing.",
      "success_criteria": "Query performance benchmarks, data consistency validation, backup/recovery verification."
    }}
  }},
  "impact": {{
    "Performance Testing": {{
      "technical_risk": "Specific technical consequences of not performing performance testing.",
      "business_impact": "Business consequences including revenue, reputation, and operational disruption.",
      "mitigation_value": "Expected risk reduction and business value from performing the testing."
    }},
    "Security Testing": {{
      "technical_risk": "Security vulnerabilities and attack vectors that remain unaddressed.",
      "business_impact": "Compliance violations, data breach costs, reputation damage, legal liability.",
      "mitigation_value": "Security posture improvement and risk reduction achieved."
    }}
  }},
  "quality_assurance": {{
    "validation_performed": true,
    "consistency_check": "passed|warning|failed",
    "completeness_score": 0.95,
    "recommendations_actionable": true
  }}
}}
```

**QUALITY REQUIREMENTS:**
- All testing descriptions must be at least 50 characters and include specific tools/methods
- Risk reasoning must reference specific aspects of the requirement
- Component analysis must include at least 2 components unless requirement is very simple
- Impact analysis must include both technical and business perspectives
- All recommendations must be actionable and measurable

Provide a thorough, accurate assessment that serves as a reliable foundation for decision-making.
"""

        return prompt

def enhanced_get_gpt_assessment(prompt: str, api_key: str, model: str = GPT_MODEL) -> Dict[str, Any]:
    """Enhanced GPT assessment with validation, retries, and quality assurance."""
    
    if not api_key:
        print("Warning: No OpenAI API Key provided. Returning enhanced simulated response.")
        return simulate_enhanced_gpt_response()
    
    validator = RiskAssessmentValidator()
    
    for attempt in range(MAX_RETRIES):
        try:
            client = openai.OpenAI(api_key=api_key)
            
            # Try primary model first
            current_model = model if attempt == 0 else FALLBACK_MODEL
            
            response = client.chat.completions.create(
                model=current_model,
                messages=[
                    {
                        "role": "system", 
                        "content": "You are an expert software risk analyst with 15+ years of experience in non-functional requirements assessment. Provide accurate, detailed, and actionable risk assessments."
                    },
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.3,  # Lower temperature for more consistent results
                max_tokens=4000,  # Ensure sufficient space for detailed response
            )
            
            content = response.choices[0].message.content
            parsed_response = parse_enhanced_gpt_response(content, validator)
            
            # Validate and enhance response
            enhanced_response = validate_and_enhance_response(parsed_response, validator)
            
            # Add metadata about the assessment process
            enhanced_response["_metadata"] = {
                "model_used": current_model,
                "attempt": attempt + 1,
                "timestamp": datetime.now().isoformat(),
                "validation_applied": True
            }
            
            return enhanced_response
            
        except openai.AuthenticationError:
            print("Error: OpenAI Authentication Failed. Check your API key.")
            raise
        except openai.RateLimitError:
            print(f"Error: OpenAI Rate Limit Exceeded. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))  # Exponential backoff
                continue
            raise
        except openai.APITimeoutError:
            print(f"Error: OpenAI API Timeout. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            raise
        except openai.APIConnectionError:
            print(f"Error: OpenAI API Connection Failed. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            raise
        except Exception as e:
            print(f"Error calling OpenAI API (attempt {attempt + 1}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            return {"error": f"Failed after {MAX_RETRIES} attempts: {str(e)}"}
    
    return {"error": f"Maximum retries ({MAX_RETRIES}) exceeded"}

def parse_enhanced_gpt_response(response_content: str, validator: RiskAssessmentValidator) -> Dict[str, Any]:
    """Enhanced parsing with validation and error recovery."""
    
    try:
        parsed_data = json.loads(response_content)
        
        # Validate required keys
        missing_keys = [key for key in REQUIRED_RESPONSE_KEYS if key not in parsed_data]
        if missing_keys:
            print(f"Warning: Missing required keys: {missing_keys}")
            parsed_data["_validation_warnings"] = f"Missing keys: {missing_keys}"
            
            # Add default values for missing keys
            for key in missing_keys:
                if key == "risk":
                    parsed_data[key] = "Medium"
                elif key == "reasoning":
                    parsed_data[key] = "Assessment completed with limited information."
                elif key in ["mandatory_testing", "recommended_testing", "component_analysis", "impact"]:
                    parsed_data[key] = {}
        
        return parsed_data
        
    except json.JSONDecodeError as e:
        print(f"Error: Failed to decode GPT response as JSON: {e}")
        print("Raw response:", response_content[:500] + "..." if len(response_content) > 500 else response_content)
        
        # Attempt to extract partial information
        return extract_partial_response(response_content)
    except Exception as e:
        print(f"Error parsing GPT response: {e}")
        return {"error": f"Response parsing failed: {e}"}

def extract_partial_response(content: str) -> Dict[str, Any]:
    """Extracts partial information from malformed responses."""
    
    partial_response = {
        "risk": "Medium",
        "reasoning": "Response parsing encountered issues, assessment may be incomplete.",
        "mandatory_testing": {},
        "recommended_testing": {},
        "component_analysis": {},
        "impact": {},
        "_parsing_warning": "Partial extraction from malformed response"
    }
    
    # Try to extract risk level
    risk_match = re.search(r'"risk":\s*"(High|Medium|Low)"', content, re.IGNORECASE)
    if risk_match:
        partial_response["risk"] = risk_match.group(1)
    
    # Try to extract reasoning
    reasoning_match = re.search(r'"reasoning":\s*"([^"]*)"', content)
    if reasoning_match:
        partial_response["reasoning"] = reasoning_match.group(1)
    
    return partial_response

def validate_and_enhance_response(response: Dict[str, Any], validator: RiskAssessmentValidator) -> Dict[str, Any]:
    """Validates and enhances the response for quality and completeness."""
    
    enhanced_response = response.copy()
    validation_notes = []
    
    # Validate risk level
    risk_valid, risk_message = validator.validate_risk_level(enhanced_response.get("risk"))
    if not risk_valid:
        enhanced_response["risk"] = "Medium"  # Default to Medium
        validation_notes.append(f"Risk level corrected: {risk_message}")
    
    # Validate and enhance reasoning
    reasoning_valid, reasoning_message, enhanced_reasoning = validator.validate_reasoning_quality(
        enhanced_response.get("reasoning", ""), 
        enhanced_response.get("_original_requirement", "")
    )
    if enhanced_reasoning:
        enhanced_response["reasoning"] = enhanced_reasoning
        validation_notes.append(reasoning_message)
    
    # Validate testing recommendations
    testing_valid, testing_message, enhanced_mandatory, enhanced_recommended = validator.validate_testing_recommendations(
        enhanced_response.get("mandatory_testing", {}),
        enhanced_response.get("recommended_testing", {})
    )
    if not testing_valid:
        enhanced_response["mandatory_testing"] = enhanced_mandatory
        enhanced_response["recommended_testing"] = enhanced_recommended
        validation_notes.append(testing_message)
    
    # Validate component analysis
    component_valid, component_message, enhanced_components = validator.validate_component_analysis(
        enhanced_response.get("component_analysis", {}),
        enhanced_response.get("_original_requirement", "")
    )
    if not component_valid:
        enhanced_response["component_analysis"] = enhanced_components
        validation_notes.append(component_message)
    
    # Add validation metadata
    if validation_notes:
        enhanced_response["_validation_applied"] = validation_notes
    
    # Add quality score
    enhanced_response["_quality_score"] = calculate_response_quality(enhanced_response)
    
    return enhanced_response

def calculate_response_quality(response: Dict[str, Any]) -> float:
    """Calculates a quality score for the response."""
    
    score = 0.0
    max_score = 10.0
    
    # Risk and reasoning quality (2 points)
    if response.get("risk") in VALID_RISK_LEVELS:
        score += 1
    if len(response.get("reasoning", "")) > 100:
        score += 1
    
    # Testing recommendations completeness (3 points)
    mandatory_testing = response.get("mandatory_testing", {})
    if len(mandatory_testing) >= 2:
        score += 1
    if any(len(str(desc)) > 50 for test_group in mandatory_testing.values() for desc in test_group.values()):
        score += 1
    
    recommended_testing = response.get("recommended_testing", {})
    if len(recommended_testing) >= 3:
        score += 1
    
    # Component analysis quality (2 points)
    component_analysis = response.get("component_analysis", {})
    if len(component_analysis) >= 1:
        score += 1
    if any(len(str(comp)) > 50 for comp in component_analysis.values()):
        score += 1
    
    # Impact analysis quality (2 points)
    impact = response.get("impact", {})
    if len(impact) >= 2:
        score += 1
    if any(len(str(imp)) > 50 for imp in impact.values()):
        score += 1
    
    # Additional quality checks (1 point)
    if not response.get("error") and len(response.get("_validation_applied", [])) <= 2:
        score += 1
    
    return round(score / max_score, 2)

def simulate_enhanced_gpt_response() -> Dict[str, Any]:
    """Provides an enhanced simulated response for development/testing."""
    
    import random
    
    risk_level = random.choice(VALID_RISK_LEVELS)
    
    return {
        "risk": risk_level,
        "reasoning": f"This requirement presents {risk_level.lower()} non-functional risk based on technical complexity analysis, potential integration challenges, performance requirements, and business impact assessment. The evaluation considers system architecture implications, scalability needs, security considerations, and operational requirements.",
        "confidence_score": round(random.uniform(0.7, 0.95), 2),
        "assessment_metadata": {
            "context_quality": round(random.uniform(0.6, 0.9), 2),
            "analysis_depth": "comprehensive",
            "similar_cases_used": 0
        },
        "mandatory_testing": {
            "Performance Testing": {
                "API": "Execute comprehensive load testing using JMeter with user loads up to expected peak capacity. Measure response times, throughput, and resource utilization under sustained load conditions.",
                "System": "Conduct end-to-end performance testing including database operations, network latency, and system resource consumption under realistic usage scenarios."
            },
            "Operational Acceptance Testing": {
                "Deployment": "Validate deployment procedures including blue-green deployment strategies, rollback mechanisms, and production environment readiness checks.",
                "Monitoring": "Verify monitoring system integration, alert configurations, dashboard functionality, and incident response automation."
            },
            "Single-user Performance Testing": {
                "User Experience": "Test individual user interaction performance, page load times, and responsiveness across different devices and network conditions."
            }
        },
        "recommended_testing": {
            "Security Testing": {
                "priority": "Critical",
                "approach": "Conduct penetration testing, vulnerability scanning, and security code review. Validate authentication, authorization, and data protection mechanisms.",
                "tools": ["OWASP ZAP", "Burp Suite", "SonarQube"],
                "deliverables": "Security assessment report with remediation roadmap and compliance verification."
            },
            "Scalability Testing": {
                "priority": "Important",
                "approach": "Progressive load testing to identify scaling bottlenecks and validate auto-scaling mechanisms under varying load conditions.",
                "tools": ["JMeter", "LoadRunner", "Artillery"],
                "deliverables": "Scalability analysis with capacity planning recommendations and performance optimization suggestions."
            }
        },
        "component_analysis": {
            "API": {
                "risks": ["Response time degradation under load", "Rate limiting effectiveness", "Error handling consistency"],
                "testing_strategy": "API contract testing, load testing with various payload sizes, error condition simulation, and performance monitoring.",
                "success_criteria": "Response times < 2 seconds for 95% of requests, error rates < 0.1%, successful handling of peak load."
            },
            "Database": {
                "risks": ["Query performance degradation", "Connection pool exhaustion", "Data consistency issues"],
                "testing_strategy": "Database performance testing, concurrent connection testing, transaction integrity validation, and backup/recovery procedures.",
                "success_criteria": "Query execution times within acceptable limits, successful handling of concurrent connections, zero data corruption incidents."
            }
        },
        "impact": {
            "Performance Testing": {
                "technical_risk": "Undetected performance bottlenecks leading to system failures under production load conditions.",
                "business_impact": "Service outages resulting in revenue loss, customer dissatisfaction, and potential SLA violations.",
                "mitigation_value": "Early identification of performance issues enabling proactive optimization and capacity planning."
            },
            "Security Testing": {
                "technical_risk": "Unidentified vulnerabilities exposing system to security breaches and data compromise.",
                "business_impact": "Data breach costs, regulatory fines, reputation damage, and legal liability exposure.",
                "mitigation_value": "Comprehensive security posture validation reducing breach probability and compliance risk."
            }
        },
        "quality_assurance": {
            "validation_performed": True,
            "consistency_check": "passed",
            "completeness_score": 0.95,
            "recommendations_actionable": True
        },
        "_quality_score": 0.92,
        "_metadata": {
            "model_used": "simulation",
            "attempt": 1,
            "timestamp": datetime.now().isoformat(),
            "validation_applied": True
        }
    }

# Backward compatibility functions
def compose_prompt(requirement_text: str, context: Dict, similar_requirements: Optional[List] = None) -> str:
    """Backward compatibility wrapper for compose_enhanced_prompt."""
    return EnhancedPromptComposer.compose_enhanced_prompt(requirement_text, context, similar_requirements)

def get_gpt_assessment(prompt: str, api_key: str) -> Dict[str, Any]:
    """Backward compatibility wrapper for enhanced_get_gpt_assessment."""
    return enhanced_get_gpt_assessment(prompt, api_key)

def parse_gpt_response(response_content: str) -> Dict[str, Any]:
    """Backward compatibility wrapper for parse_enhanced_gpt_response."""
    validator = RiskAssessmentValidator()
    return parse_enhanced_gpt_response(response_content, validator)

def simulate_gpt_response() -> Dict[str, Any]:
    """Backward compatibility wrapper for simulate_enhanced_gpt_response."""
    return simulate_enhanced_gpt_response()

class AdvancedRiskValidator:
    """Advanced validation system for enhanced quality assurance."""
    
    @staticmethod
    def perform_advanced_validation(response: Dict[str, Any], requirement_text: str, context: Dict) -> Dict[str, Any]:
        """Performs comprehensive advanced validation beyond basic checks."""
        
        validation_results = {}
        
        # 1. Logical Consistency Check
        validation_results["logical_consistency"] = AdvancedRiskValidator._check_logical_consistency(response)
        
        # 2. Completeness Analysis
        validation_results["completeness_analysis"] = AdvancedRiskValidator._analyze_response_completeness(response)
        
        # 3. Risk Justification Alignment
        validation_results["risk_justification"] = AdvancedRiskValidator._validate_risk_reasoning_alignment(response)
        
        # 4. Testing Adequacy Assessment
        validation_results["testing_adequacy"] = AdvancedRiskValidator._assess_testing_coverage_adequacy(response)
        
        # 5. Business Context Alignment
        validation_results["business_alignment"] = AdvancedRiskValidator._check_business_context_alignment(response, context)
        
        # 6. Technical Feasibility
        validation_results["technical_feasibility"] = AdvancedRiskValidator._validate_technical_recommendations(response)
        
        # Calculate advanced quality score
        advanced_score = AdvancedRiskValidator._calculate_advanced_quality_score(validation_results)
        
        # Add validation metadata
        response["_advanced_validation"] = validation_results
        response["_advanced_quality_score"] = advanced_score
        response["_quality_level"] = AdvancedRiskValidator._determine_quality_level(advanced_score)
        
        return response
    
    @staticmethod
    def _check_logical_consistency(response: Dict[str, Any]) -> Dict[str, Any]:
        """Checks for logical consistency across different response sections."""
        
        issues = []
        score = 1.0
        
        risk_level = response.get("risk", "").lower()
        reasoning = response.get("reasoning", "").lower()
        
        # Check if reasoning supports risk level
        if risk_level == "high" and not any(keyword in reasoning for keyword in ["critical", "significant", "major", "high", "severe"]):
            issues.append("High risk level not well-supported by reasoning language")
            score -= 0.3
        
        if risk_level == "low" and any(keyword in reasoning for keyword in ["critical", "severe", "major threat", "high risk"]):
            issues.append("Low risk level conflicts with reasoning language")
            score -= 0.3
        
        # Check testing recommendations alignment with risk level
        mandatory_testing = response.get("mandatory_testing", {})
        if risk_level == "high" and len(mandatory_testing) < 2:
            issues.append("High risk should have more comprehensive mandatory testing")
            score -= 0.2
        
        # Check component analysis alignment
        component_analysis = response.get("component_analysis", {})
        impact = response.get("impact", {})
        
        if len(component_analysis) > 0 and len(impact) == 0:
            issues.append("Component analysis present but impact analysis missing")
            score -= 0.2
        
        return {
            "score": max(0.0, score),
            "issues": issues,
            "passed": len(issues) == 0
        }
    
    @staticmethod
    def _analyze_response_completeness(response: Dict[str, Any]) -> Dict[str, Any]:
        """Analyzes response completeness and depth."""
        
        completeness_score = 0.0
        details = {}
        
        # Check required fields presence and quality
        required_checks = {
            "risk": lambda x: x in VALID_RISK_LEVELS,
            "reasoning": lambda x: len(x) >= 100,
            "mandatory_testing": lambda x: len(x) >= 2,
            "recommended_testing": lambda x: len(x) >= 1,
            "component_analysis": lambda x: len(x) >= 1,
            "impact": lambda x: len(x) >= 1
        }
        
        for field, check_func in required_checks.items():
            value = response.get(field, "")
            if check_func(value):
                completeness_score += 1.0 / len(required_checks)
                details[field] = "complete"
            else:
                details[field] = "incomplete"
        
        # Check depth of analysis
        depth_indicators = 0
        total_possible = 5
        
        # Check reasoning depth
        reasoning = response.get("reasoning", "")
        if len(reasoning) >= 200:
            depth_indicators += 1
        
        # Check testing detail
        mandatory_testing = response.get("mandatory_testing", {})
        total_test_descriptions = sum(len(str(desc)) for category in mandatory_testing.values() for desc in category.values())
        if total_test_descriptions >= 500:
            depth_indicators += 1
        
        # Check component detail
        component_analysis = response.get("component_analysis", {})
        if any(len(str(comp)) >= 100 for comp in component_analysis.values()):
            depth_indicators += 1
        
        # Check impact analysis detail
        impact = response.get("impact", {})
        if any(len(str(imp)) >= 80 for imp in impact.values()):
            depth_indicators += 1
        
        # Check for specific tools/methodologies mentioned
        response_text = json.dumps(response)
        tools_mentioned = ["JMeter", "OWASP", "LoadRunner", "Burp Suite", "Artillery", "SonarQube"]
        if any(tool in response_text for tool in tools_mentioned):
            depth_indicators += 1
        
        depth_score = depth_indicators / total_possible
        final_score = (completeness_score + depth_score) / 2
        
        return {
            "score": final_score,
            "completeness_score": completeness_score,
            "depth_score": depth_score,
            "details": details,
            "depth_indicators": depth_indicators
        }
    
    @staticmethod
    def _validate_risk_reasoning_alignment(response: Dict[str, Any]) -> Dict[str, Any]:
        """Validates that risk level is well-justified by reasoning."""
        
        risk_level = response.get("risk", "").lower()
        reasoning = response.get("reasoning", "").lower()
        
        # Define risk indicators for each level
        high_risk_indicators = ["critical", "severe", "major", "significant impact", "high complexity", "business critical"]
        medium_risk_indicators = ["moderate", "some risk", "manageable", "standard", "typical"]
        low_risk_indicators = ["minimal", "low impact", "straightforward", "simple", "routine"]
        
        alignment_score = 0.5  # Base score
        
        if risk_level == "high":
            high_mentions = sum(1 for indicator in high_risk_indicators if indicator in reasoning)
            if high_mentions >= 2:
                alignment_score = 1.0
            elif high_mentions >= 1:
                alignment_score = 0.8
            else:
                alignment_score = 0.3
        
        elif risk_level == "medium":
            medium_mentions = sum(1 for indicator in medium_risk_indicators if indicator in reasoning)
            high_mentions = sum(1 for indicator in high_risk_indicators if indicator in reasoning)
            low_mentions = sum(1 for indicator in low_risk_indicators if indicator in reasoning)
            
            if medium_mentions >= 1 or (high_mentions == 1 and low_mentions == 1):
                alignment_score = 1.0
            elif high_mentions >= 2:
                alignment_score = 0.4  # Should probably be high risk
            elif low_mentions >= 2:
                alignment_score = 0.4  # Should probably be low risk
            else:
                alignment_score = 0.7
        
        elif risk_level == "low":
            low_mentions = sum(1 for indicator in low_risk_indicators if indicator in reasoning)
            high_mentions = sum(1 for indicator in high_risk_indicators if indicator in reasoning)
            
            if low_mentions >= 1 and high_mentions == 0:
                alignment_score = 1.0
            elif high_mentions >= 1:
                alignment_score = 0.3  # Inconsistent
            else:
                alignment_score = 0.7
        
        return {
            "score": alignment_score,
            "risk_level": risk_level,
            "reasoning_length": len(reasoning),
            "alignment_quality": "excellent" if alignment_score >= 0.9 else "good" if alignment_score >= 0.7 else "needs_improvement"
        }
    
    @staticmethod
    def _assess_testing_coverage_adequacy(response: Dict[str, Any]) -> Dict[str, Any]:
        """Assesses adequacy of testing recommendations."""
        
        mandatory_testing = response.get("mandatory_testing", {})
        recommended_testing = response.get("recommended_testing", {})
        risk_level = response.get("risk", "").lower()
        
        coverage_score = 0.0
        adequacy_details = {}
        
        # Check mandatory testing coverage
        mandatory_categories = len(mandatory_testing)
        expected_mandatory = 3 if risk_level == "high" else 2 if risk_level == "medium" else 1
        
        if mandatory_categories >= expected_mandatory:
            coverage_score += 0.4
            adequacy_details["mandatory_coverage"] = "adequate"
        else:
            adequacy_details["mandatory_coverage"] = f"insufficient (has {mandatory_categories}, needs {expected_mandatory})"
        
        # Check recommended testing coverage
        recommended_categories = len(recommended_testing)
        expected_recommended = 4 if risk_level == "high" else 3 if risk_level == "medium" else 2
        
        if recommended_categories >= expected_recommended:
            coverage_score += 0.3
            adequacy_details["recommended_coverage"] = "adequate"
        else:
            adequacy_details["recommended_coverage"] = f"insufficient (has {recommended_categories}, needs {expected_recommended})"
        
        # Check for specific testing types based on risk level
        all_testing = {**mandatory_testing, **recommended_testing}
        critical_tests = ["Performance Testing", "Security Testing"]
        
        if risk_level == "high":
            critical_coverage = sum(1 for test in critical_tests if test in all_testing)
            if critical_coverage == len(critical_tests):
                coverage_score += 0.3
                adequacy_details["critical_test_coverage"] = "complete"
            else:
                adequacy_details["critical_test_coverage"] = f"missing {len(critical_tests) - critical_coverage} critical tests"
        else:
            coverage_score += 0.2  # Less stringent for lower risk
            adequacy_details["critical_test_coverage"] = "appropriate for risk level"
        
        return {
            "score": min(1.0, coverage_score),
            "details": adequacy_details,
            "mandatory_count": mandatory_categories,
            "recommended_count": recommended_categories
        }
    
    @staticmethod
    def _check_business_context_alignment(response: Dict[str, Any], context: Dict) -> Dict[str, Any]:
        """Checks alignment with business context and priorities."""
        
        alignment_score = 0.5  # Base score
        alignment_details = {}
        
        business_critical = context.get("business_critical", False)
        priority = context.get("priority", "medium").lower()
        risk_level = response.get("risk", "").lower()
        
        # Check risk level alignment with business criticality
        if business_critical and risk_level != "low":
            alignment_score += 0.3
            alignment_details["criticality_alignment"] = "appropriate"
        elif business_critical and risk_level == "low":
            alignment_score -= 0.2
            alignment_details["criticality_alignment"] = "risk level may be too low for business critical system"
        else:
            alignment_details["criticality_alignment"] = "reasonable"
        
        # Check priority alignment
        if priority == "high" and risk_level == "high":
            alignment_score += 0.2
        elif priority == "low" and risk_level in ["medium", "high"]:
            alignment_score -= 0.1
            alignment_details["priority_alignment"] = "risk level seems high for low priority item"
        else:
            alignment_details["priority_alignment"] = "aligned"
        
        return {
            "score": max(0.0, min(1.0, alignment_score)),
            "details": alignment_details,
            "business_context_considered": True
        }
    
    @staticmethod
    def _validate_technical_recommendations(response: Dict[str, Any]) -> Dict[str, Any]:
        """Validates technical feasibility and appropriateness of recommendations."""
        
        feasibility_score = 0.8  # Start optimistic
        feasibility_details = {}
        
        # Check for realistic tool recommendations
        response_text = json.dumps(response)
        
        # Valid testing tools
        valid_tools = ["JMeter", "LoadRunner", "Artillery", "OWASP ZAP", "Burp Suite", "SonarQube", "Selenium", "Postman"]
        mentioned_tools = [tool for tool in valid_tools if tool in response_text]
        
        if mentioned_tools:
            feasibility_details["tool_recommendations"] = f"valid tools mentioned: {mentioned_tools}"
            feasibility_score += 0.1
        else:
            feasibility_details["tool_recommendations"] = "no specific tools mentioned"
        
        # Check for realistic methodologies
        methodologies = ["load testing", "penetration testing", "vulnerability scanning", "performance monitoring"]
        mentioned_methodologies = [method for method in methodologies if method in response_text.lower()]
        
        if len(mentioned_methodologies) >= 2:
            feasibility_details["methodology_coverage"] = "comprehensive"
            feasibility_score += 0.1
        else:
            feasibility_details["methodology_coverage"] = "limited"
        
        return {
            "score": min(1.0, feasibility_score),
            "details": feasibility_details,
            "tools_mentioned": mentioned_tools,
            "methodologies_mentioned": mentioned_methodologies
        }
    
    @staticmethod
    def _calculate_advanced_quality_score(validation_results: Dict[str, Any]) -> float:
        """Calculates weighted advanced quality score."""
        
        total_score = 0.0
        
        for category, weight in ADVANCED_VALIDATION_WEIGHTS.items():
            if category in validation_results:
                category_score = validation_results[category].get("score", 0.0)
                total_score += category_score * weight
        
        return round(total_score, 3)
    
    @staticmethod
    def _determine_quality_level(score: float) -> str:
        """Determines quality level based on score."""
        
        for level, threshold in QUALITY_THRESHOLDS.items():
            if score >= threshold:
                return level
        
        return "poor"
