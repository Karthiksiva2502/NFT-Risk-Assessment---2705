# Main Streamlit application file
import streamlit as st
import file_parser
import chroma_logic
import gpt_logic
import pdf_generator
import req_quality_checker
import risk_visualization
import historical_learning  # Import the new historical learning module
import time
import pandas as pd
import json
import openai # Import the openai library
from streamlit_chat import message  # Streamlit chat library for clean UI
from plotly.graph_objects import Figure as go  # Import plotly.graph_objects as go

# Apply custom styling to the app - this must be the first Streamlit command
st.set_page_config(layout="wide", page_title="NFT Requirement Risk Assessor", page_icon="🛡️")

# Custom CSS for better look and feel
st.markdown("""
<style>
    /* Main background gradient */
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    /* Header styling */
    h1, h2, h3 {
        color: #2c3e50;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    h1 {
        text-align: center;
        padding: 20px 0;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        border-bottom: 2px solid #3498db;
        margin-bottom: 30px;
        background-color: rgba(255, 255, 255, 0.7);
        border-radius: 10px;
    }
    
    /* Card-like styling for containers */
    .stTabs [data-baseweb="tab-panel"] {
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    /* Make sidebar more distinct */
    [data-testid="stSidebar"] {
        background-color: rgba(236, 240, 243, 0.9);
        border-right: 1px solid #ddd;
        padding: 10px;
    }
    
    /* Buttons styling */
    .stButton > button {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        border: none;
        padding: 5px 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }
    .stButton > button:hover {
        background-color: #2980b9;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    /* Success and error messages */
    .stSuccess, .stInfo {
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Tables and dataframes */
    [data-testid="stTable"] {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    /* Assessment results */
    .element-container:has(h3:contains("Assessment Results")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        margin: 15px 0;
    }
    
    /* AI Assistant styling */
    .element-container:has(h3:contains("AI Assistant")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        margin: 15px 0;
    }
    
    /* Chat container */
    .chat-container {
        background-color: rgba(255, 255, 255, 0.9) !important;
        border: none !important;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05) !important;
    }
    
    /* Text areas */
    .stTextArea textarea {
        border-radius: 8px;
        border: 1px solid #ddd;
    }
    
    /* Expandable sections */
    .streamlit-expanderHeader {
        background-color: rgba(236, 240, 243, 0.9);
        border-radius: 5px;
    }
    
    /* Status indicators */
    .element-container:has(p:contains("Approved")) {
        color: #27ae60;
    }
    .element-container:has(p:contains("Rejected")) {
        color: #e74c3c;
    }
    .element-container:has(p:contains("Pending")) {
        color: #f39c12;
    }
</style>
""", unsafe_allow_html=True)

# --- Initialize session state ---
# Initialize API key in session state first since check_mandatory_fields() depends on it
if 'api_key_input_global' not in st.session_state:
    st.session_state.api_key_input_global = ""

if 'assessment_result' not in st.session_state:
    st.session_state.assessment_result = None
if 'similar_requirements' not in st.session_state:
    st.session_state.similar_requirements = None
if 'current_requirement_text' not in st.session_state:
    st.session_state.current_requirement_text = ""
if 'current_context' not in st.session_state:
    st.session_state.current_context = {} # Will be populated by sidebar
if 'assessment_id' not in st.session_state:
    st.session_state.assessment_id = None
if 'all_fields_filled' not in st.session_state:
    st.session_state.all_fields_filled = False
if 'project_type_selection' not in st.session_state: # To store the project type
    st.session_state.project_type_selection = 'New Project' # Default
if 'quality_check_result' not in st.session_state:
    st.session_state.quality_check_result = None
# Ensure the radio button's state key is initialized
if 'ctx_project_type_sidebar_global' not in st.session_state:
    st.session_state.ctx_project_type_sidebar_global = 'New Project'
if 'batch_assessment_results' not in st.session_state:
    st.session_state.batch_assessment_results = [] # For storing results of batch processing
# Add session state for user-configurable search parameters
if 'user_similarity_threshold' not in st.session_state:
    st.session_state.user_similarity_threshold = chroma_logic.DEFAULT_SIMILARITY_THRESHOLD # Default from chroma_logic
if 'user_n_results' not in st.session_state:
    st.session_state.user_n_results = chroma_logic.DEFAULT_N_RESULTS # Default from chroma_logic
# Add session state for API key validation
if 'api_key_valid' not in st.session_state:
    st.session_state.api_key_valid = False
# Add session state for Phase 1 features
if 'dashboard_tab_selected' not in st.session_state:
    st.session_state.dashboard_tab_selected = False
if 'component_map_tab_selected' not in st.session_state:
    st.session_state.component_map_tab_selected = False

# Function to analyze if input is sufficient
def is_input_sufficient(requirement_text, context):
    """
    Analyzes if the provided requirement text and context are sufficient for assessment.
    Returns True if sufficient, False if minimal/insufficient.
    """
    if not requirement_text:
        return False
    
    # Check word count (minimal threshold)
    word_count = len(requirement_text.split())
    if word_count < 10:
        return False
    
    # Check for very generic or vague requirements
    generic_phrases = ['performance', 'testing', 'system', 'application', 'requirement', 'need', 'should', 'must']
    meaningful_words = [word for word in requirement_text.lower().split() if word not in generic_phrases and len(word) > 3]
    
    if len(meaningful_words) < 5:
        return False
    
    # Look for non-functional aspects in the requirement text
    nfr_keywords = {
        'performance': ['performance', 'speed', 'response time', 'fast', 'slow', 'latency', 'throughput'],
        'security': ['security', 'secure', 'authentication', 'authorization', 'encryption', 'privacy', 'confidential'],
        'reliability': ['reliability', 'uptime', 'availability', 'failover', 'recovery', 'backup', 'fault-tolerant'],
        'scalability': ['scalability', 'scale', 'load', 'concurrent', 'simultaneous', 'users', 'traffic'],
        'maintainability': ['maintainability', 'maintenance', 'support', 'update', 'upgrade', 'patch'],
        'usability': ['usability', 'user-friendly', 'intuitive', 'ease of use', 'accessible', 'accessibility']
    }
    
    # Count non-functional aspects covered
    nfr_coverage = 0
    requirement_lower = requirement_text.lower()
    
    for category, keywords in nfr_keywords.items():
        for keyword in keywords:
            if keyword in requirement_lower:
                nfr_coverage += 1
                break  # Count only one match per category
    
    # Skip the AI assistant conversation if at least 3 NFR aspects are already covered
    # and context has substantial information
    if nfr_coverage >= 3 and context and len(context) > 4:
        return True
        
    # Check if context already has sufficient NFR information
    if context:
        context_values = ' '.join(str(value) for value in context.values() if value)
        context_word_count = len(context_values.split())
        
        # If substantial context is provided, requirements might be sufficient
        if context_word_count > 100:
            return True
    
    return False

# Function to generate AI questions based on current input
def generate_ai_questions(requirement_text, context, api_key):
    """
    Uses GPT-4o to generate relevant questions based on the minimal input provided.
    """
    try:
        client = openai.OpenAI(api_key=api_key)
        
        prompt = f"""
        The user has provided requirement information:
        
        Requirement Text: "{requirement_text}"
        
        Current Context: {json.dumps(context, indent=2)}
        
        As an expert requirement analyst, generate exactly 10 specific, targeted questions that would help gather the missing critical information needed for a comprehensive non-functional risk assessment. 
        
        Focus on:
        - Performance requirements and expectations
        - Security and compliance needs
        - Scalability and load requirements
        - Integration and compatibility aspects
        - Operational and maintenance considerations
        - Business impact and criticality
        - User experience requirements
        - Data handling and storage needs
        - Recovery and disaster planning
        - Monitoring and alerting requirements
        
        Format each question clearly and make them specific to the provided context. Return only the questions, one per line, numbered 1-10.
        """
        
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert requirements analyst specializing in gathering missing information for comprehensive risk assessments."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        questions_text = response.choices[0].message.content
        questions = [q.strip() for q in questions_text.split('\n') if q.strip() and any(c.isdigit() for c in q[:3])]
        
        # Clean up questions (remove numbering)
        cleaned_questions = []
        for q in questions:
            # Remove leading numbers and dots
            cleaned_q = q
            if '. ' in q[:5]:
                cleaned_q = q.split('. ', 1)[1] if len(q.split('. ', 1)) > 1 else q
            cleaned_questions.append(cleaned_q)
        
        return cleaned_questions[:10]  # Limit to 10 questions
        
    except Exception as e:
        st.error(f"Error generating questions: {str(e)}")
        return [
            "What are the expected performance requirements for this system?",
            "What is the expected user load or concurrent users?",
            "Are there any specific security or compliance requirements?",
            "What are the critical data types that will be handled?",
            "What are the expected response time requirements?",
            "Are there any third-party integrations required?",
            "What are the availability requirements (uptime)?",
            "What are the disaster recovery requirements?",
            "Are there any specific browser or device compatibility needs?",
            "What are the expected growth projections for this system?"
        ]

# Function to handle AI chat conversation (streamlined without individual responses)
def handle_ai_chat(questions, api_key):
    """
    Manages the AI chat conversation for collecting additional requirement information.
    """
    st.markdown("---")
    st.markdown("### 🤖 AI Assistant - Additional Information Required")
    st.info("Please provide additional details by answering the following questions for a comprehensive scope assessment:")
    
    # Create a container for the chat
    chat_container = st.container()
    
    with chat_container:
        # Display chat history in a styled container
        st.markdown("""
        <style>
        .chat-container {
            max-height: 400px;
            overflow-y: auto;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f9f9f9;
            margin-bottom: 20px;
        }
        .question-message {
            background-color: #e3f2fd;
            padding: 10px;
            border-radius: 15px;
            margin: 5px 0;
            margin-right: 50px;
            position: relative;
        }
        .answer-message {
            background-color: #e8f5e8;
            padding: 10px;
            border-radius: 15px;
            margin: 5px 0;
            margin-left: 50px;
            text-align: right;
            position: relative;
        }
        .assistant-avatar {
            left: -40px;
            background-color: #2196f3;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            position: absolute;
            top: 5px;
        }
        .user-avatar {
            right: -40px;
            background-color: #4caf50;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            position: absolute;
            top: 5px;
        }
        </style>
        """, unsafe_allow_html=True)
        
        # Chat messages container
        st.markdown('<div class="chat-container">', unsafe_allow_html=True)
        
        # Display previous Q&A pairs
        for i in range(st.session_state.current_question_index):
            if i < len(questions):
                question = questions[i]
                answer = st.session_state.chat_responses.get(f"question_{i + 1}", "")
                
                # Display question
                st.markdown(f'''
                <div class="question-message">
                    <div class="assistant-avatar">AI</div>
                    <strong>Question {i + 1}:</strong><br>{question}
                </div>
                ''', unsafe_allow_html=True)
                
                # Display answer if provided
                if answer:
                    st.markdown(f'''
                    <div class="answer-message">
                        <div class="user-avatar">You</div>
                        <strong>Your Answer:</strong><br>{answer}
                    </div>
                    ''', unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Handle current question
    if st.session_state.current_question_index < len(questions):
        current_question = questions[st.session_state.current_question_index]
        
        # Show current question
        st.markdown(f"**Question {st.session_state.current_question_index + 1} of {len(questions)}:**")
        st.markdown(f"🤖 **AI Assistant:** {current_question}")
        
        # Input for user response
        col1, col2 = st.columns([4, 1])
        with col1:
            user_input = st.text_input("Your answer:", key=f"chat_input_{st.session_state.current_question_index}", placeholder="Type your answer here...")
        
        with col2:
            send_button = st.button("Next", key=f"send_btn_{st.session_state.current_question_index}", type="primary")
        
        # Process user response - move to next question immediately
        if send_button and user_input.strip():
            # Store the response
            st.session_state.chat_responses[f"question_{st.session_state.current_question_index + 1}"] = user_input
            
            # Move to next question immediately
            st.session_state.current_question_index += 1
            
            st.rerun()
    
    else:
        # All questions answered - proceed with analysis
        st.success("🎉 All questions answered! Processing your comprehensive requirement analysis...")
        
        # Compile all responses into context
        compiled_responses = []
        for i, question in enumerate(questions):
            answer = st.session_state.chat_responses.get(f"question_{i + 1}", "")
            if answer:
                compiled_responses.append(f"Q{i+1}: {question}\nA{i+1}: {answer}")
        
        # Add to current context
        st.session_state.current_context['ai_gathered_info'] = "\n\n".join(compiled_responses)
        
        # Update requirement text with gathered info
        enhanced_requirement = f"""
        Original Requirement: {st.session_state.current_requirement_text}
        
        Additional Information Gathered Through AI Assistant:
        {chr(10).join(compiled_responses)}
        """
        
        st.session_state.current_requirement_text = enhanced_requirement
        
        # Reset chat state
        st.session_state.chat_active = False
        st.session_state.chat_history = []
        st.session_state.chat_pending_questions = []
        st.session_state.chat_responses = {}
        st.session_state.current_question_index = 0
        
        # Proceed with comprehensive analysis
        with st.spinner("Performing comprehensive analysis with all gathered information..."):
            try:
                current_api_key = st.session_state.api_key_input_global
                collection = chroma_logic.get_or_create_collection(current_api_key)
                embedding = chroma_logic.generate_embedding(enhanced_requirement, current_api_key)
                st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                    collection,
                    embedding,
                    n_results=st.session_state.user_n_results,
                    custom_threshold=st.session_state.user_similarity_threshold
                )
                
                # Prepare comprehensive context
                context_for_prompt = {}
                project_name_val = st.session_state.current_context.get('project_name')
                if project_name_val: context_for_prompt["Project Name"] = project_name_val
                project_type_val = st.session_state.current_context.get('project_type')
                if project_type_val: context_for_prompt["Project Type"] = project_type_val
                
                # Add all contextual information
                new_project_mappings = {
                    'np_critical_device_types': "Critical Device Types",
                    'np_device_coverage_priority': "Device Coverage Priority",
                    'np_max_concurrent_users': "Maximum Concurrent Users",
                    'np_target_response_time': "Target Response Time",
                    'np_load_test_scenarios': "Load Test Scenarios",
                    'np_resource_utilization_limits': "Resource Utilization Limits",
                    'np_operational_recovery_process': "Operational Recovery Process",
                    'np_monitoring_requirements': "Monitoring Requirements",
                    'np_batch_processing_window': "Batch Processing Window",
                    'np_infrastructure_dependencies': "Infrastructure Dependencies"
                }
                enhancement_mappings = {
                    'enh_compatibility_impact': "Compatibility Impact",
                    'enh_performance_baseline': "Performance Baseline",
                    'enh_regression_testing_scope': "Regression Testing Scope",
                    'enh_expected_performance_change': "Expected Performance Change",
                    'enh_operational_procedure_updates': "Operational Procedure Updates",
                    'enh_deployment_window': "Deployment Window",
                    'enh_stress_test_priority': "Stress Test Priority",
                    'enh_rollback_strategy': "Rollback Strategy",
                    'enh_user_impact_assessment': "User Impact Assessment",
                    'enh_monitoring_adjustments': "Monitoring Adjustments"
                }
                active_mappings = new_project_mappings if project_type_val == 'New Project' else enhancement_mappings
                for key_prefix, desc_label in active_mappings.items():
                    session_key = f"ctx_{key_prefix}_sidebar_global"
                    value = st.session_state.get(session_key)
                    if value: context_for_prompt[desc_label] = value
                
                # Add AI gathered information
                if st.session_state.current_context.get('ai_gathered_info'):
                    context_for_prompt["AI Assistant Gathered Information"] = st.session_state.current_context['ai_gathered_info']
                
                prompt = gpt_logic.compose_prompt(enhanced_requirement, context_for_prompt, st.session_state.similar_requirements)
                gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)

                if gpt_response and "error" in gpt_response:
                    st.error(f"Analysis failed: {gpt_response['error']}")
                    st.session_state.assessment_result = None; st.session_state.assessment_id = None
                elif gpt_response:
                    st.session_state.assessment_result = gpt_response
                    doc_id = chroma_logic.add_assessment(
                        collection, enhanced_requirement, embedding,
                        gpt_response.get('risk'), gpt_response.get('reasoning'),
                        gpt_response.get('recommendations'), gpt_response.get('impact'),
                        st.session_state.current_context.get('project_name', 'N/A')
                    )
                    st.session_state.assessment_id = doc_id
                    if doc_id: 
                        st.success("Comprehensive analysis complete!")
                        st.rerun()
                    else: st.error("Failed to save to database.")
                else:
                    st.error("Analysis failed. No response."); st.session_state.assessment_result = None; st.session_state.assessment_id = None
            except Exception as e:
                st.error(f"Analysis error: {e}"); st.session_state.assessment_result = None; st.session_state.assessment_id = None

st.title("NFT Requirement Risk Assessment Tool")

# Initialize chat-related session state variables
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'chat_pending_questions' not in st.session_state:
    st.session_state.chat_pending_questions = []
if 'chat_responses' not in st.session_state:
    st.session_state.chat_responses = {}
if 'chat_active' not in st.session_state:
    st.session_state.chat_active = False
if 'current_question_index' not in st.session_state:
    st.session_state.current_question_index = 0

# Define lists of widget keys for each project type for easier state management
new_project_widget_keys = [
    'ctx_np_critical_device_types_sidebar_global',
    'ctx_np_device_coverage_priority_sidebar_global',
    'ctx_np_max_concurrent_users_sidebar_global',
    'ctx_np_target_response_time_sidebar_global',
    'ctx_np_load_test_scenarios_sidebar_global',
    'ctx_np_resource_utilization_limits_sidebar_global',
    'ctx_np_operational_recovery_process_sidebar_global',
    'ctx_np_monitoring_requirements_sidebar_global',
    'ctx_np_batch_processing_window_sidebar_global',
    'ctx_np_infrastructure_dependencies_sidebar_global'
]
enhancement_widget_keys = [
    'ctx_enh_compatibility_impact_sidebar_global',
    'ctx_enh_performance_baseline_sidebar_global',
    'ctx_enh_regression_testing_scope_sidebar_global',
    'ctx_enh_expected_performance_change_sidebar_global',
    'ctx_enh_operational_procedure_updates_sidebar_global',
    'ctx_enh_deployment_window_sidebar_global',
    'ctx_enh_stress_test_priority_sidebar_global',
    'ctx_enh_rollback_strategy_sidebar_global',
    'ctx_enh_user_impact_assessment_sidebar_global',
    'ctx_enh_monitoring_adjustments_sidebar_global'
]

# Function to check if all mandatory fields are filled
def check_mandatory_fields(current_project_type): # Added current_project_type argument
    # Check if API key is provided
    if not st.session_state.api_key_input_global:
        return False
    
    # Common mandatory fields
    common_required = [
        'ctx_project_name_sidebar_global',
        'ctx_project_type_sidebar_global' # Project type itself is always required
    ]
    for field in common_required:
        if field not in st.session_state or not st.session_state[field]:
            return False

    # Dynamically set required fields based on project type
    project_type_specific_required = []
    if current_project_type == 'New Project': # Use argument here
        project_type_specific_required = new_project_widget_keys
    elif current_project_type == 'Enhancement': # Use argument here
        project_type_specific_required = enhancement_widget_keys

    for field in project_type_specific_required:
        if field not in st.session_state or not st.session_state[field]:
            return False
            
    return True

# Function to handle state changes when project type is modified
def project_type_changed_callback():
    selected_type = st.session_state.ctx_project_type_sidebar_global
    st.session_state.current_context['project_type'] = selected_type
    
    # Clear states of the non-selected type's widgets and their context entries
    if selected_type == 'New Project':
        for wk in enhancement_widget_keys:
            if wk in st.session_state:
                st.session_state.pop(wk, None) # Remove widget state
        enh_ctx_keys = [k for k in st.session_state.current_context if k.startswith('enh_')]
        for k_ctx in enh_ctx_keys:
            st.session_state.current_context.pop(k_ctx, None)
    elif selected_type == 'Enhancement':
        for wk in new_project_widget_keys:
            if wk in st.session_state:
                st.session_state.pop(wk, None) # Remove widget state
        np_ctx_keys = [k for k in st.session_state.current_context if k.startswith('np_')]
        for k_ctx in np_ctx_keys:
            st.session_state.current_context.pop(k_ctx, None)
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.similar_requirements = None
    # This will be recalculated based on new state
    st.session_state.all_fields_filled = False
    
    # Don't call st.rerun() here as it's within a callback
    # Setting a flag instead to avoid the warning
    st.session_state.needs_rerun = True

# --- Sidebar (Contextual Info always visible, API key always visible) ---
st.sidebar.header("Configuration")
# api_key variable is local to this scope, session state holds the persistent value
st.sidebar.text_input("Enter OpenAI API Key: *", type="password", key="api_key_input_global", help="Your OpenAI API key is required for analysis.")
st.sidebar.header("Contextual Information (for New Assessment)")
st.sidebar.markdown("##### All fields are mandatory *")
st.session_state.current_context['project_name'] = st.sidebar.text_input(
    "Project Name: *", key='ctx_project_name_sidebar_global'
)

# Define project type radio button and assign its on_change callback
st.sidebar.radio(
    "Is this a new project or an enhancement? *",
    ('New Project', 'Enhancement'),
    key='ctx_project_type_sidebar_global', # This session state key is updated by the radio
    on_change=project_type_changed_callback
)

# Determine active project type from session state for rendering
active_project_type = st.session_state.ctx_project_type_sidebar_global
# Ensure current_context reflects this, though callback also does this.
st.session_state.current_context['project_type'] = active_project_type

st.sidebar.info(f"Showing questions for: **{active_project_type}**")

# Conditional questions based on project type
if active_project_type == 'New Project':
    st.sidebar.markdown("---")
    st.sidebar.markdown("##### New Project Details *")
    # The callback should have cleared enhancement widget states.
    # Now, render New Project widgets with the new questions.
    st.session_state.current_context['np_critical_device_types'] = st.sidebar.text_input(
        "Critical Device Types: *", key='ctx_np_critical_device_types_sidebar_global'
    )
    st.session_state.current_context['np_device_coverage_priority'] = st.sidebar.radio(
        "Device Coverage Priority: *", 
        ("Critical paths only", "Major functionality", "Comprehensive"),
        key='ctx_np_device_coverage_priority_sidebar_global'
    )
    st.session_state.current_context['np_max_concurrent_users'] = st.sidebar.selectbox(
        "Maximum Concurrent Users: *", 
        ("< 500", "500-2,000", "2,000-10,000", "> 10,000"),
        key='ctx_np_max_concurrent_users_sidebar_global'
    )
    st.session_state.current_context['np_target_response_time'] = st.sidebar.text_input(
        "Target Response Time: *", key='ctx_np_target_response_time_sidebar_global'
    )
    st.session_state.current_context['np_load_test_scenarios'] = st.sidebar.text_area(
        "Load Test Scenarios: *", height=100, key='ctx_np_load_test_scenarios_sidebar_global'
    )
    st.session_state.current_context['np_resource_utilization_limits'] = st.sidebar.radio(
        "Resource Utilization Limits: *", 
        ("< 50%", "50-70%", "70-90%", "> 90%"),
        key='ctx_np_resource_utilization_limits_sidebar_global'
    )
    st.session_state.current_context['np_operational_recovery_process'] = st.sidebar.text_area(
        "Operational Recovery Process: *", height=100, key='ctx_np_operational_recovery_process_sidebar_global'
    )
    st.session_state.current_context['np_monitoring_requirements'] = st.sidebar.text_area(
        "Monitoring Requirements: *", height=100, key='ctx_np_monitoring_requirements_sidebar_global'
    )
    st.session_state.current_context['np_batch_processing_window'] = st.sidebar.selectbox(
        "Batch Processing Window: *", 
        ("< 1 hour", "1-4 hours", "4-8 hours", "Custom"),
        key='ctx_np_batch_processing_window_sidebar_global'
    )
    st.session_state.current_context['np_infrastructure_dependencies'] = st.sidebar.text_area(
        "Infrastructure Dependencies: *", height=100, key='ctx_np_infrastructure_dependencies_sidebar_global'
    )
    
elif active_project_type == 'Enhancement':
    st.sidebar.markdown("---")
    st.sidebar.markdown("##### Enhancement Details *")
    # Render Enhancement widgets with the new questions.
    st.session_state.current_context['enh_compatibility_impact'] = st.sidebar.text_input(
        "Compatibility Impact: *", key='ctx_enh_compatibility_impact_sidebar_global'
    )
    st.session_state.current_context['enh_performance_baseline'] = st.sidebar.text_area(
        "Performance Baseline: *", height=100, key='ctx_enh_performance_baseline_sidebar_global'
    )
    st.session_state.current_context['enh_regression_testing_scope'] = st.sidebar.radio(
        "Regression Testing Scope: *", 
        ("Critical paths only", "Major functions", "Comprehensive", "Custom"),
        key='ctx_enh_regression_testing_scope_sidebar_global'
    )
    st.session_state.current_context['enh_expected_performance_change'] = st.sidebar.radio(
        "Expected Performance Change: *", 
        ("Improve", "No change", "Minor impact", "Significant impact"),
        key='ctx_enh_expected_performance_change_sidebar_global'
    )
    st.session_state.current_context['enh_operational_procedure_updates'] = st.sidebar.text_area(
        "Operational Procedure Updates: *", height=100, key='ctx_enh_operational_procedure_updates_sidebar_global'
    )
    st.session_state.current_context['enh_deployment_window'] = st.sidebar.selectbox(
        "Deployment Window: *", 
        ("Business hours", "After hours", "Weekend", "Custom timeframe"),
        key='ctx_enh_deployment_window_sidebar_global'
    )
    st.session_state.current_context['enh_stress_test_priority'] = st.sidebar.text_input(
        "Stress Test Priority: *", key='ctx_enh_stress_test_priority_sidebar_global'
    )
    st.session_state.current_context['enh_rollback_strategy'] = st.sidebar.radio(
        "Rollback Strategy: *", 
        ("None", "Partial", "Complete", "Phased"),
        key='ctx_enh_rollback_strategy_sidebar_global'
    )
    st.session_state.current_context['enh_user_impact_assessment'] = st.sidebar.text_area(
        "User Impact Assessment: *", height=100, key='ctx_enh_user_impact_assessment_sidebar_global'
    )
    st.session_state.current_context['enh_monitoring_adjustments'] = st.sidebar.text_area(
        "Monitoring Adjustments: *", height=100, key='ctx_enh_monitoring_adjustments_sidebar_global'
    )

# Check if all fields are filled after any change
# Pass the active_project_type to the check function
st.session_state.all_fields_filled = check_mandatory_fields(active_project_type)

# Display a message about mandatory fields if not all filled
if not st.session_state.all_fields_filled:
    st.sidebar.warning("⚠️ All fields marked with * are mandatory. Please fill them all to proceed.")

st.sidebar.markdown("---")
st.sidebar.header("Search Configuration")
st.session_state.user_similarity_threshold = st.sidebar.slider(
    "Similarity Distance Cutoff (lower is stricter):",
    min_value=0.1, max_value=1.5, # Cosine distance can be > 1 if embeddings are not perfectly normalized or due to numerical precision
    value=st.session_state.user_similarity_threshold,
    step=0.05,
    help="Controls how similar a past requirement must be to be shown. A lower value means only very similar results are shown."
)
st.session_state.user_n_results = st.sidebar.number_input(
    "Max Similar Results to Fetch:",
    min_value=1, max_value=20,
    value=st.session_state.user_n_results,
    step=1,
    help="The maximum number of similar past assessments to retrieve for context."
)

# --- Main App Area with Tabs ---
tab1, tab2, tab3, tab4 = st.tabs(["New Assessment", "Previous Results", "Risk Dashboard", "Learning Analytics"])

# Handle tab selection state from other tabs
if st.session_state.get("dashboard_tab_selected", False):
    tab3.selectbox = True
    st.session_state.dashboard_tab_selected = False

with tab1:
    st.header("Submit New Requirement")
    
    # Display a notice at the top if fields aren't filled
    if not st.session_state.all_fields_filled:
        st.warning("⚠️ Please fill all mandatory fields in the sidebar before proceeding.")
    
    input_method = st.radio("Choose input method:", ("Upload File", "Enter Text Manually", "Bulk Upload (CSV)"), horizontal=True, key="input_method_choice_tab1")
    uploaded_file = None
    manual_text = ""

    if input_method == "Upload File":
        uploaded_file = st.file_uploader("Upload Requirement Document (.txt or .docx)", type=['txt', 'docx'], key='file_uploader_tab1_single')
        if uploaded_file: 
            st.session_state.manual_text_tab1 = ""
            st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Enter Text Manually":
        # Show the requirement text area
        manual_text = st.text_area("Enter Requirement Text:", height=200, key='manual_text_tab1')
        st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Bulk Upload (CSV)":
        uploaded_file = st.file_uploader("Upload CSV file with a 'requirement_text' column", type=['csv'], key='file_uploader_tab1_bulk')
        st.info("Ensure your CSV has a column named 'requirement_text' (or similar like 'Requirement Text', 'requirement'). Context from the sidebar will be applied to all requirements in the file.")
        if uploaded_file:
            st.session_state.manual_text_tab1 = "" # Clear manual text
            st.session_state.assessment_result = None # Clear single assessment result
            st.session_state.assessment_id = None

    # Determine if analysis button should be enabled
    button_disabled = not st.session_state.all_fields_filled
    if input_method == "Enter Text Manually":
        button_disabled = not st.session_state.all_fields_filled or not manual_text.strip()
    elif input_method == "Bulk Upload (CSV)":
        if not uploaded_file: # Disable if no file is uploaded for bulk
            button_disabled = True
    elif input_method == "Upload File":
        if not uploaded_file: # Disable if no file is uploaded for single
            button_disabled = True

    # Disable the analyze button if mandatory fields aren't filled
    analyze_button = st.button("Analyze Requirement(s)", key="analyze_button_tab1", disabled=button_disabled)

    if analyze_button:
        st.session_state.batch_assessment_results = [] # Clear previous batch results
        st.session_state.assessment_result = None # Clear single result
        st.session_state.assessment_id = None

        if input_method == "Bulk Upload (CSV)" and uploaded_file is not None:
            requirements_list, error_msg = file_parser.parse_file(uploaded_file)
            if error_msg:
                st.error(error_msg)
            elif not requirements_list:
                st.warning("No requirements found in the CSV file or the 'requirement_text' column is empty.")
            else:
                st.info(f"Found {len(requirements_list)} requirements in the CSV. Starting batch analysis...")
                
                # Prepare context once for the whole batch
                current_api_key = st.session_state.api_key_input_global
                
                # Verify API key before starting the batch process
                try:
                    # Quick API key validation
                    if not current_api_key or len(current_api_key.strip()) < 10:
                        st.error("Invalid API key. Please enter a valid OpenAI API key.")
                        st.stop()
                        
                    # Test API connectivity
                    chroma_logic.check_openai_connectivity(current_api_key)
                except openai.AuthenticationError:
                    st.error("OpenAI authentication failed. Please check your API key and try again.")
                    st.stop()
                except Exception as e:
                    st.error(f"Error connecting to OpenAI: {str(e)}")
                    st.stop()
                    
                context_for_prompt = {}
                project_name_val = st.session_state.current_context.get('project_name')
                if project_name_val: context_for_prompt["Project Name"] = project_name_val
                project_type_val = st.session_state.current_context.get('project_type')
                if project_type_val: context_for_prompt["Project Type"] = project_type_val
                
                new_project_mappings = {
                    'np_critical_device_types': "Critical Device Types",
                    'np_device_coverage_priority': "Device Coverage Priority",
                    'np_max_concurrent_users': "Maximum Concurrent Users",
                    'np_target_response_time': "Target Response Time",
                    'np_load_test_scenarios': "Load Test Scenarios",
                    'np_resource_utilization_limits': "Resource Utilization Limits",
                    'np_operational_recovery_process': "Operational Recovery Process",
                    'np_monitoring_requirements': "Monitoring Requirements",
                    'np_batch_processing_window': "Batch Processing Window",
                    'np_infrastructure_dependencies': "Infrastructure Dependencies"
                }
                enhancement_mappings = {
                    'enh_compatibility_impact': "Compatibility Impact",
                    'enh_performance_baseline': "Performance Baseline",
                    'enh_regression_testing_scope': "Regression Testing Scope",
                    'enh_expected_performance_change': "Expected Performance Change",
                    'enh_operational_procedure_updates': "Operational Procedure Updates",
                    'enh_deployment_window': "Deployment Window",
                    'enh_stress_test_priority': "Stress Test Priority",
                    'enh_rollback_strategy': "Rollback Strategy",
                    'enh_user_impact_assessment': "User Impact Assessment",
                    'enh_monitoring_adjustments': "Monitoring Adjustments"
                }
                active_mappings = new_project_mappings if project_type_val == 'New Project' else enhancement_mappings
                for key_prefix, desc_label in active_mappings.items():
                    session_key = f"ctx_{key_prefix}_sidebar_global"
                    value = st.session_state.get(session_key)
                    if value: context_for_prompt[desc_label] = value

                batch_progress = st.progress(0)
                temp_status = st.empty()
                processed_count = 0

                for i, req_text in enumerate(requirements_list):
                    temp_status.info(f"Processing requirement {i+1}/{len(requirements_list)}: '{req_text[:50]}...'")
                    if not req_text or len(req_text.strip()) < 5: # Basic validation for each requirement
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": "Requirement text too short or empty.", 
                            "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                            "comments": "Skipped due to insufficient text.", "timestamp": int(time.time())
                        })
                        processed_count +=1
                        batch_progress.progress(processed_count / len(requirements_list))
                        continue
                    try:
                        # Attempt to get or create the collection with proper error handling
                        try:
                            collection = chroma_logic.get_or_create_collection(current_api_key)
                        except Exception as collection_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"Database connection error: {str(collection_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to connect to the database. Please check your network and credentials.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                            
                        # Generate embedding with error handling
                        try:
                            embedding = chroma_logic.generate_embedding(req_text, current_api_key)
                        except openai.AuthenticationError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Authentication Failed", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Please check your OpenAI API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except Exception as embedding_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"Embedding generation error: {str(embedding_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to create embeddings for similarity search.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        
                        # Compose prompt and get GPT assessment with error handling
                        prompt = gpt_logic.compose_prompt(req_text, context_for_prompt, None) # Passing None for similar_requirements
                        
                        try:
                            gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)
                        except openai.AuthenticationError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Authentication Failed", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Please check your OpenAI API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.RateLimitError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Rate Limit Exceeded", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "API rate limit reached. Please try again later or use a different API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.APITimeoutError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI API Timeout", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "The request to OpenAI API timed out. Try again later.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.APIConnectionError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI API Connection Error", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to connect to OpenAI API. Check your network connection.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except Exception as gpt_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"GPT assessment error: {str(gpt_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed during AI assessment.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue

                        # Process the response
                        if gpt_response and "error" not in gpt_response:
                            try:
                                doc_id = chroma_logic.add_assessment(
                                    collection, req_text, embedding,
                                    gpt_response.get('risk'), gpt_response.get('reasoning'),
                                    gpt_response.get('recommendations'), gpt_response.get('impact'),
                                    project_name_val or "N/A"
                                )
                                st.session_state.batch_assessment_results.append({
                                    "id": doc_id, "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                    **gpt_response, "status": "Pending", "comments": "", "timestamp": int(time.time())
                                })
                            except Exception as db_error:
                                st.session_state.batch_assessment_results.append({
                                    "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                    "risk": gpt_response.get('risk', 'N/A'), 
                                    "reasoning": gpt_response.get('reasoning', 'N/A'),
                                    "recommendations": gpt_response.get('recommendations', 'N/A'), 
                                    "impact": gpt_response.get('impact', 'N/A'), 
                                    "status": "Error-DB", 
                                    "comments": f"Assessment successful but database storage failed: {str(db_error)}", 
                                    "timestamp": int(time.time())
                                })
                        else:
                            error_detail = gpt_response.get('error', 'Unknown GPT error') if gpt_response else "No GPT response"
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": error_detail, "recommendations": "N/A", 
                                "impact": "N/A", "status": "Error", "comments": "Failed during GPT assessment.", "timestamp": int(time.time())
                            })
                    except Exception as e:
                        # Catch-all for any other unexpected errors
                        import traceback
                        error_traceback = traceback.format_exc()
                        error_type = type(e).__name__
                        
                        # Log detailed error info to console/log file
                        print(f"ERROR in batch processing item {i+1}: {error_type}: {str(e)}")
                        print(f"Traceback: {error_traceback}")
                        
                        # Add to results with more detailed error info
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": f"Unexpected error ({error_type}): {str(e)}", "recommendations": "N/A", 
                            "impact": "N/A", "status": "Error", "comments": "Failed during processing. Check logs for details.", 
                            "timestamp": int(time.time())
                        })
                    processed_count += 1
                    batch_progress.progress(processed_count / len(requirements_list))
                
                temp_status.success(f"Batch analysis complete for {len(requirements_list)} requirements.")
                batch_progress.empty()

        elif input_method == "Upload File" and uploaded_file is not None:
            try:
                requirement_text, error_msg = file_parser.parse_file(uploaded_file)
                if error_msg:
                    st.error(error_msg)
                    requirement_text = None
                if requirement_text is None and not error_msg: 
                    st.error("Unsupported file type or empty file.")
            except Exception as e: 
                st.error(f"Error reading file: {e}")
                requirement_text = None
                
            st.session_state.current_requirement_text = requirement_text
            # --- Standard single requirement processing logic ---
            if requirement_text:
                with st.spinner("Analyzing..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        # Use the wrapped function with automatic reconnection logic
                        collection = chroma_logic.get_or_create_collection_with_retry(current_api_key)
                        embedding = chroma_logic.generate_embedding(requirement_text, current_api_key)
                        st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                            collection,
                            embedding,
                            n_results=st.session_state.user_n_results,
                            custom_threshold=st.session_state.user_similarity_threshold
                        )
                        
                        context_for_prompt = {}
                        project_name_val = st.session_state.current_context.get('project_name')
                        if project_name_val: context_for_prompt["Project Name"] = project_name_val
                        project_type_val = st.session_state.current_context.get('project_type')
                        if project_type_val: context_for_prompt["Project Type"] = project_type_val
                        new_project_mappings = {
                            'np_critical_device_types': "Critical Device Types",
                            'np_device_coverage_priority': "Device Coverage Priority",
                            'np_max_concurrent_users': "Maximum Concurrent Users",
                            'np_target_response_time': "Target Response Time",
                            'np_load_test_scenarios': "Load Test Scenarios",
                            'np_resource_utilization_limits': "Resource Utilization Limits",
                            'np_operational_recovery_process': "Operational Recovery Process",
                            'np_monitoring_requirements': "Monitoring Requirements",
                            'np_batch_processing_window': "Batch Processing Window",
                            'np_infrastructure_dependencies': "Infrastructure Dependencies"
                        }
                        enhancement_mappings = {
                            'enh_compatibility_impact': "Compatibility Impact",
                            'enh_performance_baseline': "Performance Baseline",
                            'enh_regression_testing_scope': "Regression Testing Scope",
                            'enh_expected_performance_change': "Expected Performance Change",
                            'enh_operational_procedure_updates': "Operational Procedure Updates",
                            'enh_deployment_window': "Deployment Window",
                            'enh_stress_test_priority': "Stress Test Priority",
                            'enh_rollback_strategy': "Rollback Strategy",
                            'enh_user_impact_assessment': "User Impact Assessment",
                            'enh_monitoring_adjustments': "Monitoring Adjustments"
                        }
                        active_mappings = new_project_mappings if project_type_val == 'New Project' else enhancement_mappings
                        for key_prefix, desc_label in active_mappings.items():
                            session_key = f"ctx_{key_prefix}_sidebar_global"
                            value = st.session_state.get(session_key)
                            if value: context_for_prompt[desc_label] = value
                        
                        prompt = gpt_logic.compose_prompt(requirement_text, context_for_prompt, st.session_state.similar_requirements)
                        gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)

                        if gpt_response and "error" in gpt_response:
                            st.error(f"Analysis failed: {gpt_response['error']}")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                        elif gpt_response:
                            st.session_state.assessment_result = gpt_response
                            doc_id = chroma_logic.add_assessment(
                                collection, requirement_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                st.session_state.current_context.get('project_name', 'N/A')
                            )
                            st.session_state.assessment_id = doc_id
                            if doc_id: 
                                st.success("Analysis complete!")
                            else: 
                                st.error("Failed to save to database.")
                        else:
                            st.error("Analysis failed. No response.")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}")
                        st.session_state.assessment_result = None
                        st.session_state.assessment_id = None

        elif input_method == "Enter Text Manually":
            requirement_text = st.session_state.manual_text_tab1
            st.session_state.current_requirement_text = requirement_text

            if not requirement_text: 
                st.warning("Please provide requirement text.")
            else:
                # Always start with AI Assistant chat for comprehensive assessment
                if not st.session_state.chat_active:
                    st.info("🔍 Starting comprehensive scope assessment with AI Assistant...")
                    
                    # Generate questions and start chat
                    st.session_state.chat_active = True
                    st.session_state.chat_pending_questions = generate_ai_questions(
                        requirement_text, 
                        st.session_state.current_context, 
                        st.session_state.api_key_input_global
                    )
                    st.session_state.current_question_index = 0
                    st.rerun()
    
    # Handle AI chat display outside the analyze button logic
    if input_method == "Enter Text Manually" and st.session_state.chat_active:
        handle_ai_chat(st.session_state.chat_pending_questions, st.session_state.api_key_input_global)

    # Display assessment results if available - add check for chat_active to ensure results don't show during chat
    if st.session_state.assessment_result and "error" not in st.session_state.assessment_result and input_method != "Bulk Upload (CSV)" and not st.session_state.chat_active:
        st.markdown("---")
        
        # Add requirement quality check section
        st.header("Requirement Quality Analysis")
        
        # Get requirement text from session state
        req_text = st.session_state.current_requirement_text
        
        # Perform basic quality check first (this doesn't require API call)
        basic_quality = req_quality_checker.perform_basic_quality_checks(req_text)
        
        # Display basic checks in an expander
        with st.expander("Basic Quality Checks", expanded=True):
            if basic_quality["warnings"]:
                for warning in basic_quality["warnings"]:
                    st.warning(warning)
            else:
                st.success("No basic quality issues detected.")
            
            # Show word count
            st.info(f"Word count: {basic_quality['simple_checks'].get('word_count', 0)}")
        
        # Comprehensive quality analysis with AI
        with st.spinner("Analyzing requirement quality..."):
            quality_results = req_quality_checker.analyze_requirement_quality(
                req_text, 
                st.session_state.current_context,
                st.session_state.api_key_input_global
            )
        
        if "error" in quality_results:
            st.error(f"Quality analysis error: {quality_results['error']}")
        else:
            # Create columns for the quality scores
            st.subheader("Quality Scores")
            
            # Get scores
            scores = quality_results.get("scores", {})
            
            # Create a progress bar for the overall score
            overall = scores.get("overall", 0)
            overall_color = "#ff5252" if overall < 4 else "#FFC107" if overall < 7 else "#4CAF50"
            
            st.markdown(f"### Overall Quality: {overall}/10")
            st.progress(overall/10, text=f"{overall}/10")
            
            # Create columns for individual metrics
            cols = st.columns(5)
            
            # Define the metrics to display
            metrics = ["clarity", "testability", "completeness", "consistency", "traceability"]
            
            # Display each metric in a column
            for i, metric in enumerate(metrics):
                score = scores.get(metric, 0)
                cols[i].metric(
                    metric.capitalize(), 
                    f"{score}/10",
                    delta=None
                )
            
            # Display analysis and suggestions
            st.subheader("Analysis & Improvement Suggestions")
            
            # Create tabs for each quality aspect
            quality_tabs = st.tabs(["Clarity", "Testability", "Completeness", "Consistency", "Traceability"])
            
            for i, metric in enumerate(metrics):
                with quality_tabs[i]:
                    # Display analysis
                    st.markdown(f"**Analysis:**")
                    st.info(quality_results.get("analysis", {}).get(metric, "No analysis available."))
                    
                    # Display suggestions
                    st.markdown(f"**Improvement Suggestions:**")
                    suggestions = quality_results.get("suggestions", {}).get(metric, [])
                    if suggestions:
                        for j, suggestion in enumerate(suggestions):
                            st.markdown(f"- {suggestion}")
                    else:
                        st.markdown("No specific suggestions available.")
        
        st.markdown("---")
        st.header("Risk Assessment Results")
        if st.session_state.similar_requirements:
            with st.expander("Similar Past Assessments Found"):
                for sim_req in st.session_state.similar_requirements:
                    meta = sim_req.get('metadata', {})
                    st.markdown(f"**ID:** `{meta.get('id')}` (Similarity: {1-sim_req.get('distance', 1):.2f})")
                    st.markdown(f"**Risk:** {meta.get('risk', 'N/A')}")
                    st.text_area(f"Requirement (similar):", value=meta.get('requirement_text', 'N/A'), height=70, disabled=True, key=f"sim_req_text_disp_{meta.get('id')}")
                    st.markdown("---")

        res = st.session_state.assessment_result
        st.subheader(f"Risk Level: {res.get('risk', 'N/A')}")
        st.markdown(f"**Reasoning:** {res.get('reasoning', 'N/A')}")
        
        # Display mandatory testing (new structured format)
        if 'mandatory_testing' in res:
            st.markdown("### Mandatory Testing (Centrica Services)")
            mandatory_testing = res.get('mandatory_testing', {})
            
            if isinstance(mandatory_testing, dict):  # New structured format
                for test_type, components in mandatory_testing.items():
                    st.markdown(f"#### {test_type}")
                    if isinstance(components, dict):  # Structured components
                        for component, details in components.items():
                            st.markdown(f"**{component}:** {details}")
                    else:  # Fallback for string value
                        st.markdown(components)
            else:  # Fallback for string format
                st.markdown(mandatory_testing)
        
        # Display recommended testing (new structured format)
        if 'recommended_testing' in res:
            st.markdown("### Recommended Testing")
            recommended_testing = res.get('recommended_testing', {})
            
            if isinstance(recommended_testing, dict):  # New structured format
                for test_type, components in recommended_testing.items():
                    st.markdown(f"#### {test_type}")
                    if isinstance(components, dict):  # Structured components
                        for component, details in components.items():
                            st.markdown(f"**{component}:** {details}")
                    else:  # Fallback for string value
                        st.markdown(components)
            else:  # Fallback for string format
                st.markdown(recommended_testing)
        elif 'recommendations' in res:  # Backward compatibility
            st.markdown(f"**Recommended Testing:** {res.get('recommendations', 'N/A')}")
        
        # Display component analysis (new structured format)
        if 'component_analysis' in res:
            st.markdown("### Component Analysis")
            component_analysis = res.get('component_analysis', {})
            
            if isinstance(component_analysis, dict):  # New structured format
                for component, tests in component_analysis.items():
                    st.markdown(f"#### {component}")
                    if isinstance(tests, dict):  # Structured tests
                        for test_type, details in tests.items():
                            st.markdown(f"**{test_type}:** {details}")
                    else:  # Fallback for string value
                        st.markdown(tests)
            else:  # Fallback for string format
                st.markdown(component_analysis)
            
        # Display impact (new structured format)
        if 'impact' in res:
            st.markdown("### Impact of Not Testing")
            impact = res.get('impact', {})
            
            if isinstance(impact, dict):  # New structured format
                for test_type, consequences in impact.items():
                    st.markdown(f"**{test_type}:** {consequences}")
            else:  # Fallback for string format
                st.markdown(impact)
        
        st.markdown("---")
        st.subheader("Architect Review")
        
        # Add feedback collection for learning
        with st.expander("🧠 Assessment Feedback (for AI Learning)", expanded=False):
            st.info("Help improve the AI's accuracy by providing feedback on this assessment:")
            
            col1_feedback, col2_feedback = st.columns(2)
            with col1_feedback:
                actual_outcome = st.selectbox(
                    "What was the actual risk level?",
                    ["Select...", "High", "Medium", "Low"],
                    key="actual_outcome_feedback"
                )
            with col2_feedback:
                feedback_comments = st.text_area(
                    "Additional Comments (optional):",
                    height=100,
                    key="feedback_comments",
                    placeholder="Any insights about why the AI assessment was accurate/inaccurate..."
                )
        
        review_comment = st.text_area("Review Comments:", key="review_comment_tab1")
        
        col1_approve, col2_reject = st.columns(2)
        if col1_approve.button("Mark as Approved", key="approve_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Approved", review_comment)
                    if success: 
                        st.success("Marked as Approved!")
                        st.session_state.assessment_result['status'] = "Approved"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback
                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        if col2_reject.button("Mark as Rejected", key="reject_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Rejected", review_comment)
                    if success: 
                        st.success("Marked as Rejected!")
                        st.session_state.assessment_result['status'] = "Rejected"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback
                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        st.markdown("---")
        pdf_report_data = {
            'requirement_text': st.session_state.current_requirement_text,
            'context': st.session_state.current_context, 
            **res,
            'status': st.session_state.assessment_result.get('status', 'Pending'),
            'comments': st.session_state.assessment_result.get('comments', ''),
            'timestamp': int(time.time()), 
            'id': st.session_state.assessment_id or "N/A",
            'project_name': st.session_state.current_context.get('project_name', 'N/A')
        }
        if 'approved' in pdf_report_data: 
            del pdf_report_data['approved']
        pdf_data = pdf_generator.generate_pdf_report(pdf_report_data)
        st.download_button("Download Report as PDF", pdf_data, f"assessment_{st.session_state.assessment_id or 'report'}.pdf", "application/pdf", key="download_pdf_tab1")

with tab2:
    st.header("Past Assessments")
    current_api_key_for_tab2 = st.session_state.get("api_key_input_global") # Consistent usage
    if not current_api_key_for_tab2:
        st.info("Please enter OpenAI API Key in the sidebar to view past assessments.")
    else:
        try:
            collection = chroma_logic.get_or_create_collection(current_api_key_for_tab2)
            # Make sure to get all assessments correctly
            all_assessments = chroma_logic.get_all_assessments(collection)
            
            # Debug statement to check if assessments are being retrieved
            st.write(f"Found {len(all_assessments)} past assessment(s) in the database.")

            # --- Ensure all assessments have 'project_name' ---
            for a in all_assessments:
                if 'project_name' not in a or not a['project_name']:
                    a['project_name'] = 'N/A'

            # --- Filtering & Sorting controls moved into Tab 2 main area ---
            st.markdown("#### Filter & Sort Past Assessments")
            filter_cols = st.columns(3)
            with filter_cols[0]:
                filter_project_name_tab2 = st.text_input("Filter by Project Name:", key="filter_project_name_main_tab2")
            with filter_cols[1]:
                filter_risk_level_tab2 = st.multiselect("Filter by Risk Level:", options=["High", "Medium", "Low"], key="filter_risk_level_main_tab2")
            with filter_cols[2]:
                filter_approval_status_tab2 = st.selectbox("Filter by Status:", options=["All", "Pending", "Approved", "Rejected"], index=0, key="filter_approval_status_main_tab2")

            sort_cols = st.columns(2)
            with sort_cols[0]:
                sort_column_tab2 = st.selectbox("Sort by:", options=["Timestamp", "Project Name", "Risk Level", "Approval Status"], key="sort_column_main_tab2")
            with sort_cols[1]:
                sort_ascending_tab2 = st.radio("Sort Order:", options=["Ascending", "Descending"], key="sort_order_main_tab2", horizontal=True) == "Ascending"
            st.markdown("---")

            # --- Debug: Show count of loaded assessments ---
            st.caption(f"Total assessments in database: {len(all_assessments)}")

            if not all_assessments:
                st.info("No past assessments found. Complete an analysis in the 'New Assessment' tab to see results here.")
            else:
                # Create a dictionary of assessments by ID for quick lookup
                assessment_dict = {assessment.get('id'): assessment for assessment in all_assessments if assessment.get('id')}
                
                filtered_assessments = all_assessments.copy()  # Make a copy before filtering
                
                # --- Defensive filtering logic: always use .get() and lower() safely ---
                if filter_project_name_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if filter_project_name_tab2.lower() in str(a.get('project_name', '')).lower()
                    ]
                
                if filter_risk_level_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('risk') in filter_risk_level_tab2
                    ]
                
                if filter_approval_status_tab2 != "All":
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('status') == filter_approval_status_tab2
                    ]
                
                # Debug message for filtered results
                st.caption(f"Filtered to {len(filtered_assessments)} assessment(s) based on current filters")
                
                if filtered_assessments:
                    # Improved sorting function with proper error handling
                    def get_sort_key_tab2(assessment):
                        if sort_column_tab2 == "Timestamp":
                            return assessment.get('timestamp', 0) 
                        elif sort_column_tab2 == "Project Name":
                            return str(assessment.get('project_name', '')).lower()
                        elif sort_column_tab2 == "Risk Level":
                            risk_level = assessment.get('risk', '')
                            # Map risk levels to numeric values for sorting
                            risk_values = {"Low": 0, "Medium": 1, "High": 2}
                            return risk_values.get(risk_level, -1)
                        elif sort_column_tab2 == "Approval Status":
                            return str(assessment.get('status', '')).lower()
                        return 0  # Default fallback
                    
                    # Apply sorting
                    filtered_assessments.sort(key=get_sort_key_tab2, reverse=not sort_ascending_tab2)

                    st.write(f"Displaying {len(filtered_assessments)} assessment(s):")
                    cols_names_tab2 = ["Project Name", "Risk Level", "Status", "Timestamp", "Details"]
                    header_cols_tab2 = st.columns(len(cols_names_tab2))
                    for col, name in zip(header_cols_tab2, cols_names_tab2): 
                        col.markdown(f"**{name}**")
                    st.markdown("---")

                    for assess_data in filtered_assessments:
                        row_cols_tab2 = st.columns(len(cols_names_tab2))
                        row_cols_tab2[0].write(assess_data.get('project_name', 'N/A'))
                        row_cols_tab2[1].write(assess_data.get('risk', 'N/A'))
                        row_cols_tab2[2].write(assess_data.get('status', 'N/A'))
                        # Handle timestamp safely
                        timestamp = assess_data.get('timestamp', 0)
                        if timestamp:
                            row_cols_tab2[3].write(time.strftime('%Y-%m-%d %H:%M', time.localtime(timestamp)))
                        else:
                            row_cols_tab2[3].write("Unknown")
                        
                        with row_cols_tab2[4]:
                            details_popover = st.popover("View", use_container_width=True) 
                        
                        with details_popover:
                            assess_id = assess_data.get('id')
                            full_details = assessment_dict.get(assess_id) if assess_id else None
                            
                            if full_details:
                                st.markdown(f"#### Details for ID: {full_details.get('id')}")
                                st.markdown(f"**Project:** {full_details.get('project_name', 'N/A')}")
                                
                                detail_timestamp = full_details.get('timestamp', 0)
                                if detail_timestamp:
                                    st.markdown(f"**Timestamp:** {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(detail_timestamp))}")
                                else:
                                    st.markdown("**Timestamp:** N/A")
                                
                                st.markdown(f"**Risk:** {full_details.get('risk', 'N/A')}")
                                st.markdown(f"**Status:** {full_details.get('status', 'N/A')}")
                                st.markdown(f"**Comments:** {full_details.get('comments', 'None')}")
                                st.markdown(f"**Requirement:**")
                                st.text_area("req_text_popup_disp", value=full_details.get('requirement_text','N/A'), 
                                            height=100, disabled=True, key=f"popup_req_disp_{assess_id}")
                                
                                # Display reasoning
                                st.markdown(f"**Reasoning:** {full_details.get('reasoning', 'N/A')}")
                                
                                # Display mandatory testing with new structured format
                                if 'mandatory_testing' in full_details:
                                    st.markdown("#### Mandatory Testing (Centrica Services)")
                                    mandatory_testing = full_details.get('mandatory_testing', {})
                                    
                                    if isinstance(mandatory_testing, dict):  # New structured format
                                        for test_type, components in mandatory_testing.items():
                                            st.markdown(f"**{test_type}**")
                                            if isinstance(components, dict):  # Structured components
                                                for component, details in components.items():
                                                    st.markdown(f"- *{component}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {components}")
                                    else:  # Fallback for string format
                                        st.markdown(mandatory_testing)
                                
                                # Display recommended testing with new structured format
                                if 'recommended_testing' in full_details:
                                    st.markdown("#### Recommended Testing")
                                    recommended_testing = full_details.get('recommended_testing', {})
                                    
                                    if isinstance(recommended_testing, dict):  # New structured format
                                        for test_type, components in recommended_testing.items():
                                            st.markdown(f"**{test_type}**")
                                            if isinstance(components, dict):  # Structured components
                                                for component, details in components.items():
                                                    st.markdown(f"- *{component}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {components}")
                                    else:  # Fallback for string format
                                        st.markdown(recommended_testing)
                                elif 'recommendations' in full_details:  # Backward compatibility
                                    st.markdown(f"**Recommended Testing:** {full_details.get('recommendations', 'N/A')}")
                                
                                # Display component analysis with new structured format
                                if 'component_analysis' in full_details:
                                    st.markdown("#### Component Analysis")
                                    component_analysis = full_details.get('component_analysis', {})
                                    
                                    if isinstance(component_analysis, dict):  # New structured format
                                        for component, tests in component_analysis.items():
                                            st.markdown(f"**{component}**")
                                            if isinstance(tests, dict):  # Structured tests
                                                for test_type, details in tests.items():
                                                    st.markdown(f"- *{test_type}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {tests}")
                                    else:  # Fallback for string format
                                        st.markdown(component_analysis)
                                
                                # Display impact with new structured format
                                if 'impact' in full_details:
                                    st.markdown("#### Impact of Not Testing")
                                    impact = full_details.get('impact', {})
                                    
                                    if isinstance(impact, dict):  # New structured format
                                        for test_type, consequences in impact.items():
                                            st.markdown(f"**{test_type}:** {consequences}")
                                    else:  # Fallback for string format
                                        st.markdown(f"**Impact:** {impact}")
                                
                                try:
                                    # Create PDF payload with necessary data
                                    pdf_payload = {
                                        **full_details, 
                                        'context': {'project_name': full_details.get('project_name', 'N/A')}
                                    }
                                    pdf_bytes = pdf_generator.generate_pdf_report(pdf_payload)
                                    st.download_button(
                                        "Download Report", 
                                        pdf_bytes, 
                                        f"assessment_{assess_id}.pdf", 
                                        "application/pdf", 
                                        key=f"dl_popup_btn_{assess_id}"
                                    )
                                except Exception as e_pdf: 
                                    st.error(f"PDF Error: {e_pdf}")
                            else: 
                                st.error("Details not found for this assessment.")
                        st.markdown("---")
                else:
                    st.info("No assessments match your current filter criteria. Try adjusting your filters.")
        except Exception as e:
            st.error(f"Error loading past assessments: {str(e)}")
            # Log detailed error for debugging
            st.error(f"Error details: {type(e).__name__}")
            import traceback
            st.code(traceback.format_exc())

with tab3:
    st.header("Risk Visualization Dashboard")
    current_api_key_for_tab3 = st.session_state.get("api_key_input_global")
    if not current_api_key_for_tab3:
        st.info("Please enter OpenAI API Key in the sidebar to view risk visualizations.")
    else:
        try:
            collection = chroma_logic.get_or_create_collection(current_api_key_for_tab3)
            # Get all assessments for visualization
           
            all_assessments = chroma_logic.get_all_assessments(collection)
            
            if not all_assessments:
                st.info("No assessment data available for visualization. Complete some assessments to see risk analytics.")
            else:
                # Display risk visualization dashboard
                risk_visualization.display_risk_dashboard(all_assessments)
        
        except Exception as e:
            st.error(f"Error loading risk dashboard: {str(e)}")

with tab4:
    st.header("🧠 Learning Analytics Dashboard")
    
    current_api_key_for_tab4 = st.session_state.get("api_key_input_global")
    if not current_api_key_for_tab4:
        st.info("Please enter OpenAI API Key in the sidebar to view learning analytics.")
    else:
        try:
            # Get learning dashboard data
            dashboard_data = historical_learning.get_learning_dashboard_data()
            
            if 'error' in dashboard_data:
                st.error(f"Error loading learning data: {dashboard_data['error']}")
            else:
                # Display overall metrics
                st.subheader("📈 Overall Learning Metrics")
                metrics = dashboard_data.get('overall_metrics', {})
                
                if metrics.get('total_assessments', 0) == 0:
                    st.info("🎯 No feedback data available yet. Provide feedback on assessments in the 'New Assessment' tab to see learning analytics here.")
                    st.markdown("""
                    **How to contribute to AI learning:**
                    1. Complete an assessment in the 'New Assessment' tab
                    2. When marking it as Approved/Rejected, expand the 'Assessment Feedback' section
                    3. Select the actual risk level and add comments
                    4. The AI will learn from your feedback to improve future assessments
                    """)
                else:
                    # Create metrics columns
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Total Assessments", metrics.get('total_assessments', 0))
                    with col2:
                        st.metric("Correct Predictions", metrics.get('correct_predictions', 0))
                    with col3:
                        accuracy = metrics.get('accuracy_rate', 0)
                        st.metric("Accuracy Rate", f"{accuracy:.2%}")
                    with col4:
                        improvement = metrics.get('improvement_rate', 0)
                        delta = f"+{improvement:.2%}" if improvement > 0 else f"{improvement:.2%}"
                        st.metric("Improvement Rate", delta, delta=delta)
                    
                    # Display confidence scores
                    st.subheader("🎯 Confidence Scores by Category")
                    confidence_scores = metrics.get('confidence_scores', {})
                    if confidence_scores:
                        confidence_cols = st.columns(min(len(confidence_scores), 4))
                        for i, (category, score) in enumerate(confidence_scores.items()):
                            with confidence_cols[i % 4]:
                                st.metric(category.replace('_', ' ').title(), f"{score:.2%}")
                    else:
                        st.info("Not enough data for confidence scores yet.")
                    
                    # Display daily trends
                    st.subheader("📊 Daily Accuracy Trends")
                    daily_trends = dashboard_data.get('daily_trends', [])
                    if daily_trends:
                        import plotly.express as px
                        import pandas as pd
                        
                        df_trends = pd.DataFrame(daily_trends)
                        if not df_trends.empty:
                            fig = px.line(df_trends, x='date', y='accuracy', 
                                        title='Assessment Accuracy Over Time',
                                        labels={'accuracy': 'Accuracy Rate', 'date': 'Date'})
                            fig.update_yaxes(tickformat='.0%')
                            st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("Not enough daily data for trends yet.")
                    
                    # Display error patterns
                    st.subheader("🔍 Common Error Patterns")
                    error_patterns = metrics.get('common_error_patterns', [])
                    if error_patterns:
                        for i, pattern in enumerate(error_patterns[:5]):  # Show top 5
                            with st.expander(f"Pattern {i+1}: {pattern.get('pattern', 'Unknown')}"):
                                st.write(f"**Frequency:** {pattern.get('frequency', 0):.1%}")
                                st.write(f"**Occurrences:** {pattern.get('count', 0)}")
                                st.write(f"**Average Accuracy:** {pattern.get('average_accuracy', 0):.2%}")
                                if pattern.get('affected_categories'):
                                    st.write(f"**Affected Categories:** {', '.join(pattern['affected_categories'])}")
                    else:
                        st.info("No significant error patterns detected yet.")
                    
                    # Display optimization suggestions
                    st.subheader("💡 AI Improvement Suggestions")
                    suggestions = metrics.get('optimization_suggestions', [])
                    if suggestions:
                        for suggestion in suggestions:
                            st.warning(f"💡 {suggestion}")
                    else:
                        st.success("🎉 No immediate improvements needed - AI is performing well!")
                    
                    # Display optimization recommendations
                    st.subheader("🛠️ Optimization Recommendations")
                    recommendations = dashboard_data.get('recommendations', {})
                    if recommendations.get('needs_optimization'):
                        st.error(f"⚠️ Accuracy below threshold: {recommendations.get('current_accuracy', 0):.2%}")
                        st.info(f"🎯 Target accuracy: {recommendations.get('target_accuracy', 0.75):.2%}")
                        
                        priority_areas = recommendations.get('priority_areas', [])
                        if priority_areas:
                            st.write("**Priority Areas for Improvement:**")
                            for area in priority_areas:
                                impact_color = "🔴" if area['impact'] == 'high' else "🟡"
                                st.write(f"{impact_color} {area['area']} (frequency: {area['frequency']:.1%})")
                    else:
                        st.success("✅ AI accuracy is within acceptable range!")
                        minor_improvements = recommendations.get('minor_improvements', [])
                        if minor_improvements:
                            st.info("**Minor improvements you could consider:**")
                            for improvement in minor_improvements:
                                st.write(f"• {improvement}")
                    
                    # Export functionality
                    st.subheader("📤 Export Learning Data")
                    col1_export, col2_export = st.columns(2)
                    
                    with col1_export:
                        if st.button("📊 Export Learning Metrics", use_container_width=True):
                            try:
                                metrics_json = json.dumps(dashboard_data, indent=2, default=str)
                                st.download_button(
                                    label="Download Metrics JSON",
                                    data=metrics_json,
                                    file_name=f"learning_metrics_{int(time.time())}.json",
                                    mime="application/json"
                                )
                            except Exception as e:
                                st.error(f"Export failed: {str(e)}")
                    
                    with col2_export:
                        if st.button("💾 Export Full Learning Database", use_container_width=True):
                            try:
                                export_success = historical_learning.learning_system.export_learning_data(
                                    f"learning_export_{int(time.time())}.json"
                                )
                                if export_success:
                                    st.success("✅ Learning data exported successfully!")
                                else:
                                    st.error("❌ Export failed")
                            except Exception as e:
                                st.error(f"Export failed: {str(e)}")
                    
                    # Quick insights
                    st.subheader("🧠 Quick Insights")
                    if accuracy >= 0.9:
                        st.success("🎯 Excellent! AI accuracy is above 90%")
                    elif accuracy >= 0.75:
                        st.info("👍 Good performance - AI accuracy is above 75%")
                    elif accuracy >= 0.60:
                        st.warning("⚠️ Moderate performance - consider reviewing assessment criteria")
                    else:
                        st.error("🔴 Low accuracy - immediate attention needed")
                    
                    total = metrics.get('total_assessments', 0)
                    if total < 10:
                        st.info(f"💡 Tip: Collect more feedback ({total}/10+ recommended) for better learning insights")
                    elif total >= 50:
                        st.success(f"🎉 Great! You have {total} feedback entries - excellent learning dataset!")
        
        except Exception as e:
            st.error(f"Error loading learning analytics: {str(e)}")
            import traceback
            st.code(traceback.format_exc())
