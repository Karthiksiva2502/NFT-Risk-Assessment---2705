# NFT Requirement Risk Assessment Tool

This Streamlit web application helps assess the non-functional risks associated with software requirements, particularly for projects that might involve Non-Functional Testing (NFTs) or similar digital assets, though it can be used for general software requirements.

## Features

*   **Requirement Input:** Users can upload requirement documents (.txt, .docx) or enter requirement text manually.
*   **Contextual Analysis:** The application gathers contextual information about the project (e.g., project type, data sensitivity, user volume) to aid in risk assessment.
*   **AI-Powered Risk Assessment:** Uses OpenAI's GPT-4 API to:
    *   Classify the risk of a requirement as High, Medium, or Low.
    *   Provide reasoning for the classification.
    *   Recommend non-functional testing types.
    *   Explain the impact of not performing the recommended testing.
*   **Intelligent Information Gathering:** 
    *   Automatically detects when requirement input is minimal or insufficient.
    *   Launches an interactive AI chat assistant to gather additional details.
    *   Uses GPT-4o to generate up to 10 targeted questions based on the provided context.
    *   Features a Facebook Messenger-style chat interface with AI and user avatars.
*   **Vector Database Integration:**
    *   Converts requirements into embeddings using OpenAI's `text-embedding-3-small` model.
    *   Stores these embeddings and associated assessment metadata (requirement text, risk, recommendations, project name, status, comments) in a local Chroma vector database.
    *   Implements semantic search to find similar past requirements based on meaning rather than keywords.
    *   Provides similarity percentages and match quality indicators to evaluate search results.
    *   Offers database statistics and backup functionality for collection management.
*   **Architect Review Workflow:**
    *   Allows an architect or reviewer to add comments.
    *   Provides "Approve" and "Reject" buttons to update the assessment status in the database.
*   **Historical Learning System:**
    *   **NEW!** Advanced AI learning from historical assessment feedback.
    *   Records assessment outcomes vs AI predictions for accuracy tracking.
    *   Measures prediction accuracy and improvement rates over time.
    *   Identifies error patterns and provides optimization suggestions.
    *   Learning Analytics dashboard with comprehensive performance metrics.
    *   Automatic prompt optimization recommendations based on historical data.
*   **Reporting:**
    *   Generates a PDF report for each assessment, including all details and review status.
*   **Previous Results:**
    *   A dedicated tab to view, filter, and sort past assessments.
    *   Full details of past assessments can be viewed in a popover.
    *   PDF reports for past assessments can be re-downloaded.

## Setup and Installation

*   **Prerequisites:**
    *   Python 3.8 or higher.
    *   `pip` (Python package installer).
    *   OpenAI API key with access to GPT-4o and embedding models.

*   **Install Dependencies:**
    Install the required Python packages:
    ```bash
    pip install streamlit openai chromadb pandas python-docx reportlab streamlit-chat
    ```

## Running the Application

1.  **Navigate to the Project Directory:**
    Ensure your terminal is in the root directory of the project.

2.  **Set OpenAI API Key:**
    The application requires an OpenAI API key to function. You will be prompted to enter this key in the application's sidebar. Ensure you have a valid key with access to the GPT-4o and embedding models.

3.  **Run the Streamlit App:**
    Execute the following command in your terminal:
    ```bash
    streamlit run app.py
    ```

4.  **Access the Application:**
    Once the server starts, it will typically display a local URL in your terminal (e.g., `http://localhost:8501`). Open this URL in your web browser to use the application.

## AI Chat Assistant Feature

When you click the "Analyze Requirement" button, the AI Assistant will automatically:

1. **Analyze Initial Input:** Review the information provided in the Contextual Side Bar and Requirement Text Box
2. **Launch Comprehensive Assessment:** Automatically open the "AI Assistant - Additional Information Required" chat window
3. **Ask Targeted Questions:** Present exactly 10 specific questions designed to gather all mandatory details for a complete scope assessment
4. **Streamlined Collection:** Progress through questions immediately after each answer without individual AI responses
5. **Complete Analysis:** Combine all gathered information to perform a comprehensive risk assessment only after all questions are answered

The chat interface features:
- Clean, Facebook Messenger-style design with AI and user avatars
- Automatic progression through exactly 10 targeted questions
- No individual AI responses to maintain focus and efficiency
- Progress tracking showing completed and current questions
- Comprehensive final analysis incorporating all collected information

**Important:** The final risk assessment and recommendations will only be generated after all 10 questions in the AI Assistant chat window have been answered. This ensures the most accurate and comprehensive scope assessment possible.

## Project Structure

### Core Application Files
*   `app.py`: The main Streamlit application script with AI chat functionality and Learning Analytics dashboard.
*   `chroma_logic.py`: Handles interactions with the Chroma vector database and embedding generation.
*   `file_parser.py`: Contains functions for parsing uploaded requirement documents.
*   `gpt_logic.py`: **Enhanced** GPT logic with advanced validation, quality scoring, and error handling.
*   `historical_learning.py`: **NEW!** Historical learning system for AI improvement and feedback tracking.
*   `pdf_generator.py`: Responsible for creating PDF reports of assessments.
*   `req_quality_checker.py`: Performs requirement quality analysis and validation.
*   `risk_visualization.py`: Handles risk dashboards and data visualization.
*   `requirements.txt`: Lists all Python dependencies for the project.

### Data and Logs
*   `./chroma_db/`: Directory where the local Chroma database is stored (created automatically).
*   `./feedback_db/`: **NEW!** Directory where the historical learning database is stored (created automatically).
*   `chroma_operations.log`: Operational logs for database and API operations.

### Documentation
*   `docs/ENHANCED_GPT_LOGIC_README.md`: Documentation for enhanced GPT logic features.
*   `docs/ADVANCED_ENHANCEMENTS_PROPOSAL.py`: Future enhancement proposals and roadmap.
*   `docs/ENHANCEMENT_IMPLEMENTATION_ANALYSIS.md`: Analysis of implemented vs proposed enhancements.
*   `docs/HISTORICAL_LEARNING_INTEGRATION_COMPLETE.md`: **NEW!** Complete documentation of the historical learning system.
*   `README.md`: This file.

### Testing
*   `tests/test_enhancements.py`: Comprehensive test suite for enhanced functionality.

## Notes

*   The Chroma database is stored locally in the `chroma_db` sub-directory. If you delete this directory, all past assessment data will be lost.
*   Ensure your OpenAI API key has sufficient quota and access to the specified models (`gpt-4o` and `text-embedding-3-small`).
*   The AI chat feature requires an active internet connection for real-time question generation and response processing.
