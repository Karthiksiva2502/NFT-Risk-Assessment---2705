"""
Risk Visualization Dashboard for NFT Risk Assessment Tool
Provides data visualization components for risk assessment data:
- Risk distribution by category
- Risk trend charts
- Interactive dashboard elements
"""

import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import json
from datetime import datetime

def prepare_risk_data(assessments):
    """
    Prepares assessment data for visualization by extracting key metrics.
    
    Args:
        assessments (list): List of assessment objects from the database
        
    Returns:
        pandas.DataFrame: DataFrame containing structured assessment data
    """
    if not assessments:
        return pd.DataFrame()
    
    # Extract data for visualization
    data_rows = []
    for assessment in assessments:
        # Skip assessments without necessary data
        if not assessment or not isinstance(assessment, dict):
            continue
            
        metadata = assessment.get('metadata', {})
        risk_level = metadata.get('risk', 'Unknown')
        timestamp = metadata.get('timestamp', '')
        project_name = metadata.get('project_name', 'Unknown')
          # Since Component Risk Map feature has been removed, we'll extract test types from recommendations instead
        test_types = []
        recommendations = metadata.get('recommendations', {})
        if isinstance(recommendations, str):
            try:
                recommendations = json.loads(recommendations)
            except:
                recommendations = {}
        
        if isinstance(recommendations, dict):
            test_types = list(recommendations.keys())
        elif isinstance(recommendations, list):
            test_types = recommendations
          # If we have test types from recommendations, use them
        if test_types:
            for test_type in test_types:
                if not isinstance(test_type, str):
                    continue
                data_rows.append({
                    'id': metadata.get('id', 'Unknown'),
                    'timestamp': timestamp,
                    'risk_level': risk_level,
                    'project_name': project_name,
                    'component': 'General',
                    'test_type': test_type,
                    'requirement_text': metadata.get('requirement_text', '')[:100] + '...'
                })
        else:
            # If no test types were found, add a general entry
            data_rows.append({
                'id': metadata.get('id', 'Unknown'),
                'timestamp': timestamp,
                'risk_level': risk_level,
                'project_name': project_name,
                'component': 'General',
                'test_type': 'General',
                'requirement_text': metadata.get('requirement_text', '')[:100] + '...'
            })
    
    # Create DataFrame
    df = pd.DataFrame(data_rows)
    
    # Convert timestamp to datetime if available
    if 'timestamp' in df.columns and not df.empty:
        try:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['date'] = df['timestamp'].dt.date
        except:
            df['date'] = None
    
    return df

def create_risk_distribution_chart(df):
    """
    Creates a chart showing distribution of risk levels.
    
    Args:
        df (pandas.DataFrame): DataFrame containing assessment data
        
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if df.empty:
        return go.Figure()
    
    # Count assessments by risk level
    risk_counts = df['risk_level'].value_counts().reset_index()
    risk_counts.columns = ['Risk Level', 'Count']
    
    # Custom color mapping
    color_map = {'High': '#FF5252', 'Medium': '#FFC107', 'Low': '#4CAF50', 'Unknown': '#9E9E9E'}
    
    # Create bar chart
    fig = px.bar(
        risk_counts, 
        x='Risk Level', 
        y='Count', 
        title='Risk Level Distribution',
        color='Risk Level',
        color_discrete_map=color_map,
        text='Count'
    )
    
    fig.update_traces(textposition='outside')
    fig.update_layout(
        uniformtext_minsize=8, 
        uniformtext_mode='hide',
        xaxis_title='Risk Level',
        yaxis_title='Number of Assessments',
        height=400
    )
    
    return fig

def create_component_risk_chart(df):
    """
    Creates a chart showing risk levels by component.
    
    Args:
        df (pandas.DataFrame): DataFrame containing assessment data
        
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if df.empty or 'component' not in df.columns:
        return go.Figure()
    
    # Count components by risk level
    component_risk = df.groupby(['component', 'risk_level']).size().reset_index()
    component_risk.columns = ['Component', 'Risk Level', 'Count']
    
    # Custom color mapping
    color_map = {'High': '#FF5252', 'Medium': '#FFC107', 'Low': '#4CAF50', 'Unknown': '#9E9E9E'}
    
    # Create grouped bar chart
    fig = px.bar(
        component_risk, 
        x='Component', 
        y='Count', 
        color='Risk Level',
        title='Risk Levels by Component',
        color_discrete_map=color_map,
        barmode='group',
        text='Count'
    )
    
    fig.update_traces(textposition='outside')
    fig.update_layout(
        xaxis_title='Component',
        yaxis_title='Number of Assessments',
        height=500
    )
    
    return fig

def create_risk_trend_chart(df):
    """
    Creates a chart showing risk trends over time.
    
    Args:
        df (pandas.DataFrame): DataFrame containing assessment data
        
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if df.empty or 'date' not in df.columns:
        return go.Figure()
    
    # Group by date and risk level
    trend_data = df.groupby(['date', 'risk_level']).size().reset_index()
    trend_data.columns = ['Date', 'Risk Level', 'Count']
    
    # Custom color mapping
    color_map = {'High': '#FF5252', 'Medium': '#FFC107', 'Low': '#4CAF50', 'Unknown': '#9E9E9E'}
    
    # Create line chart
    fig = px.line(
        trend_data,
        x='Date',
        y='Count',
        color='Risk Level',
        title='Risk Assessment Trends Over Time',
        color_discrete_map=color_map,
        markers=True
    )
    
    fig.update_layout(
        xaxis_title='Date',
        yaxis_title='Number of Assessments',
        height=400
    )
    
    return fig

def create_test_type_chart(df):
    """
    Creates a chart showing distribution of test types.
    
    Args:
        df (pandas.DataFrame): DataFrame containing assessment data
        
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if df.empty or 'test_type' not in df.columns:
        return go.Figure()
    
    # Count test types
    test_counts = df['test_type'].value_counts().reset_index()
    test_counts.columns = ['Test Type', 'Count']
    
    # Create horizontal bar chart
    fig = px.bar(
        test_counts,
        y='Test Type',
        x='Count',
        title='Test Type Distribution',
        color='Count',
        color_continuous_scale='Viridis',
        text='Count',
        orientation='h'
    )
    
    fig.update_traces(textposition='outside')
    fig.update_layout(
        yaxis_title='',
        xaxis_title='Number of Occurrences',
        height=500
    )
    
    return fig

def display_risk_dashboard(assessments):
    """
    Displays the complete risk visualization dashboard in Streamlit.
    
    Args:
        assessments (list): List of assessment objects from the database
    """
    st.markdown("## 📊 Risk Visualization Dashboard")
    
    if not assessments:
        st.info("No assessment data available for visualization. Complete some assessments to see risk analytics.")
        return
      # Prepare data for visualization
    df = prepare_risk_data(assessments)
    
    if df.empty:
        st.info("Could not extract visualizable data from the assessments. Please check data format.")
        return
    
    # Create dashboard layout
    col1, col2 = st.columns(2)
    
    with col1:
        # Risk distribution chart
        risk_chart = create_risk_distribution_chart(df)
        st.plotly_chart(risk_chart, use_container_width=True, key="risk_distribution_chart")
        
        # Component risk chart
        component_chart = create_component_risk_chart(df)
        st.plotly_chart(component_chart, use_container_width=True, key="component_risk_chart")
    
    with col2:
        # Risk trend chart
        trend_chart = create_risk_trend_chart(df)
        st.plotly_chart(trend_chart, use_container_width=True, key="risk_trend_chart")
        
        # Test type chart
        test_chart = create_test_type_chart(df)
        st.plotly_chart(test_chart, use_container_width=True, key="test_type_chart")
      # Display summary statistics
    st.markdown("### 📈 Summary Statistics")
    
    stats_col1, stats_col2, stats_col3 = st.columns(3)
    
    with stats_col1:
        total_assessments = df['id'].nunique()
        st.metric("Total Assessments", total_assessments)
        
    with stats_col2:
        high_risk_count = df[df['risk_level'] == 'High']['id'].nunique()
        high_risk_percent = (high_risk_count / total_assessments * 100) if total_assessments > 0 else 0
        st.metric("High Risk Assessments", f"{high_risk_count} ({high_risk_percent:.1f}%)")
        
    with stats_col3:
        unique_tests = df['test_type'].nunique()
        st.metric("Test Types", unique_tests)
    
    # Allow filtering by project
    if 'project_name' in df.columns:
        st.markdown("### 🔍 Filter by Project")
        projects = sorted(df['project_name'].unique())
        selected_project = st.selectbox("Select Project", ["All"] + list(projects))
        
        if selected_project != "All":
            filtered_df = df[df['project_name'] == selected_project]
            
            st.markdown(f"#### Risk Distribution for {selected_project}")
            project_risk_chart = create_risk_distribution_chart(filtered_df)
            st.plotly_chart(project_risk_chart, use_container_width=True)
