#!/usr/bin/env python3
"""
Test script for enhanced gpt_logic functionality
"""

from gpt_logic import (
    enhanced_get_gpt_assessment, 
    EnhancedPromptComposer, 
    RiskAssessmentValidator,
    simulate_enhanced_gpt_response,
    calculate_response_quality
)
import json

def test_enhanced_functionality():
    """Test all enhanced features"""
    print("=== Testing Enhanced GPT Logic ===\n")
    
    # Test data
    context = {
        'project_type': 'web_application',
        'priority': 'high',
        'business_critical': True,
        'performance_requirements': 'Response time < 2 seconds',
        'security_level': 'enterprise',
        'user_base': '1000+ concurrent users',
        'compliance_requirements': 'GDPR, SOX'
    }
    
    requirement = "The system must handle 1000 concurrent users with response times under 2 seconds while maintaining 99.9% uptime and ensuring data security compliance"
    
    # 1. Test Enhanced Prompt Composition
    print("1. Testing Enhanced Prompt Composition")
    print("-" * 40)
    composer = EnhancedPromptComposer()
    
    # Analyze context quality
    quality_score, suggestions = composer.analyze_context_quality(context)
    print(f"Context Quality Score: {quality_score:.1%}")
    print(f"Improvement Suggestions: {suggestions[:150]}...")
    
    # Generate enhanced prompt
    prompt = composer.compose_enhanced_prompt(requirement, context)
    print(f"Enhanced Prompt Length: {len(prompt)} characters")
    print(f"Prompt includes validation: {'QUALITY REQUIREMENTS' in prompt}")
    
    # 2. Test Validation System
    print("\n2. Testing Validation System")
    print("-" * 40)
    validator = RiskAssessmentValidator()
    
    # Test risk level validation
    risk_valid, risk_msg = validator.validate_risk_level("High")
    print(f"Valid risk level 'High': {risk_valid}")
    
    risk_invalid, risk_msg_invalid = validator.validate_risk_level("Critical")
    print(f"Invalid risk level 'Critical': {risk_invalid} - {risk_msg_invalid}")
    
    # Test reasoning validation
    short_reasoning = "This is risky"
    reasoning_valid, reasoning_msg, enhanced_reasoning = validator.validate_reasoning_quality(
        short_reasoning, requirement
    )
    print(f"Short reasoning valid: {reasoning_valid}")
    print(f"Enhanced reasoning provided: {bool(enhanced_reasoning)}")
    
    # 3. Test Enhanced Response Generation
    print("\n3. Testing Enhanced Response Generation")
    print("-" * 40)
    response = simulate_enhanced_gpt_response()
    
    print(f"Risk Level: {response.get('risk')}")
    print(f"Quality Score: {response.get('_quality_score')}")
    print(f"Confidence Score: {response.get('confidence_score')}")
    print(f"Response completeness: {len(response.keys())} keys")
    
    # Check required keys
    required_keys = ["risk", "reasoning", "mandatory_testing", "recommended_testing", "component_analysis", "impact"]
    missing_keys = [key for key in required_keys if key not in response]
    print(f"Missing required keys: {missing_keys if missing_keys else 'None'}")
    
    # 4. Test Quality Calculation
    print("\n4. Testing Quality Calculation")
    print("-" * 40)
    quality_score = calculate_response_quality(response)
    print(f"Calculated Quality Score: {quality_score}")
    
    # Test with minimal response
    minimal_response = {"risk": "Low", "reasoning": "Basic reasoning"}
    minimal_quality = calculate_response_quality(minimal_response)
    print(f"Minimal Response Quality: {minimal_quality}")
    
    # 5. Test Component Analysis
    print("\n5. Testing Component Analysis")
    print("-" * 40)
    component_analysis = response.get('component_analysis', {})
    print(f"Components identified: {list(component_analysis.keys())}")
    
    for component, details in component_analysis.items():
        print(f"  - {component}: {len(details)} risk factors")
    
    # 6. Test Testing Recommendations
    print("\n6. Testing Testing Recommendations")
    print("-" * 40)
    mandatory = response.get('mandatory_testing', {})
    recommended = response.get('recommended_testing', {})
    
    print(f"Mandatory testing categories: {len(mandatory)}")
    print(f"Recommended testing categories: {len(recommended)}")
    
    # Check for specific tools mentioned
    all_testing_text = json.dumps(mandatory) + json.dumps(recommended)
    tools = ['JMeter', 'OWASP ZAP', 'LoadRunner', 'Burp Suite']
    mentioned_tools = [tool for tool in tools if tool in all_testing_text]
    print(f"Testing tools mentioned: {mentioned_tools}")
    
    # 7. Test Impact Analysis
    print("\n7. Testing Impact Analysis")
    print("-" * 40)
    impact = response.get('impact', {})
    print(f"Impact categories analyzed: {len(impact)}")
    
    for category, impact_details in impact.items():
        technical_risk = impact_details.get('technical_risk', '')
        business_impact = impact_details.get('business_impact', '')
        print(f"  - {category}: Technical={len(technical_risk)}chars, Business={len(business_impact)}chars")
    
    # 8. Test Metadata Tracking
    print("\n8. Testing Metadata Tracking")
    print("-" * 40)
    metadata = response.get('_metadata', {})
    print(f"Metadata keys: {list(metadata.keys())}")
    print(f"Model used: {metadata.get('model_used', 'Unknown')}")
    print(f"Timestamp: {metadata.get('timestamp', 'Unknown')}")
    print(f"Validation applied: {metadata.get('validation_applied', False)}")
    
    print("\n=== Enhancement Testing Complete ===")
    print(f"Overall Assessment: The enhanced system provides comprehensive")
    print(f"risk assessment with {len(response.keys())} response elements,")
    print(f"quality score of {response.get('_quality_score', 0):.2f}, and")
    print(f"validation tracking for continuous improvement.")

if __name__ == "__main__":
    test_enhanced_functionality()
